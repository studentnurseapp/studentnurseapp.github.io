/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// --- Type Definitions for clarity ---
interface CalculatorInput {
    id: string;
    label: string;
    type: 'number' | 'select' | 'dynamicList' | 'date' | 'text';
    unit?: string;
    placeholder?: string;
    options?: { value: string; text: string; }[];
    listName?: string;
}

interface CalculatorOutput {
    id: string;
    label: string;
    unit?: string;
}

interface VisualizationParams {
    unit?: string;
    maxScore?: number;
    ranges: { label: string; max?: number; till?: number; color: string; }[];
    displayMin?: number;
    displayMax?: number;
}

interface Calculator {
    id: string;
    name: string;
    inputs: CalculatorInput[];
    outputs: CalculatorOutput[];
    formulaText: string;
    visualizationType?: 'linearGauge' | 'barChart' | 'donutChart';
    visualizationParams?: VisualizationParams;
    infoMessage?: string;
    calculate: (values: Record<string, any>) => Record<string, any>;
    getCalculationBreakdown: (values: Record<string, any>, result: Record<string, any>) => string;
    interpretResult?: (result: Record<string, any>, values?: Record<string, any>) => string;
}

interface CalculatorCategory {
    category: string;
    categoryIcon: string;
    calculators: Calculator[];
}

interface ExploreItem {
    id: string;
    name: string;
    brief: string;
    motivationalTag?: string;
    type: 'exam' | 'book' | 'podcast' | 'career';
    resources?: { type: string; title: string; author?: string }[];
    link?: string;
    lang?: string;
    url?: string;
}

interface ExploreSection {
    section: string;
    icon: string;
    description: string;
    items: ExploreItem[];
}

interface LabValue {
    test: string;
    conventionalUnits: string;
    siUnits: string;
    etiology: {
        high: string;
        low: string;
    };
    notes?: string;
    specimen?: string;
}

interface LabCategory {
    title: string;
    icon: string;
    tableId: string;
    values: LabValue[];
}


// --- Data Definitions ---

const allCalculatorsData: CalculatorCategory[] = [
    {
        category: "Foundational Calculations",
        categoryIcon: "🛠️",
        calculators: [
            {
                id: "medicationDosage",
                name: "Medication Dosage",
                inputs: [
                    { id: "desiredDose", label: "Desired Dose (D)", type: "number", unit: "mg", placeholder: "e.g., 750" },
                    { id: "doseOnHand", label: "Dose on Hand (H)", type: "number", unit: "mg", placeholder: "e.g., 250" },
                    { id: "volumeVehicle", label: "Volume/Vehicle (V)", type: "number", unit: "mL or tablets", placeholder: "e.g., 5" }
                ],
                outputs: [{ id: "amountToAdminister", label: "Amount to Administer", unit: "mL or tablets" }],
                formulaText: "X = (D / H) * V",
                calculate: function(values) {
                    const D = parseFloat(values.desiredDose);
                    const H = parseFloat(values.doseOnHand);
                    const V = parseFloat(values.volumeVehicle);
                    if (isNaN(D) || isNaN(H) || isNaN(V) || H === 0) return { error: "Invalid input. Ensure all fields are numeric and Dose on Hand is not zero." };
                    if (D < 0 || H < 0 || V < 0) return { error: "Inputs must be positive values." };
                    const result = (D / H) * V;
                    return { amountToAdminister: result.toFixed(2) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Desired Dose (D): ${values.desiredDose} ${values.desiredDose_unit || 'mg'}<br>
                        2. Dose on Hand (H): ${values.doseOnHand} ${values.doseOnHand_unit || 'mg'}<br>
                        3. Volume/Vehicle (V): ${values.volumeVehicle} ${values.volumeVehicle_unit || 'mL or tablets'}<br>
                        4. Formula: X = (D / H) * V<br>
                        5. Calculation: (${values.desiredDose} / ${values.doseOnHand}) * ${values.volumeVehicle} = <strong class="results-strong-text-color">${result.amountToAdminister} ${values.volumeVehicle_unit || 'mL or tablets'}</strong>
                    `;
                }
            },
            {
                id: "ivFlowRateMlHr",
                name: "IV Flow Rate (mL/hr)",
                inputs: [
                    { id: "totalVolume", label: "Total Volume", type: "number", unit: "mL", placeholder: "e.g., 1000" },
                    { id: "totalTimeHours", label: "Total Time", type: "number", unit: "hours", placeholder: "e.g., 8" }
                ],
                outputs: [{ id: "flowRateMlHr", label: "Flow Rate", unit: "mL/hr" }],
                formulaText: "Flow Rate (mL/hr) = Total Volume (mL) / Total Time (hours)",
                calculate: function(values) {
                    const vol = parseFloat(values.totalVolume);
                    const time = parseFloat(values.totalTimeHours);
                    if (isNaN(vol) || isNaN(time) || time === 0) return { error: "Invalid input. Ensure fields are numeric and time is not zero." };
                    if (vol < 0 || time < 0) return { error: "Inputs must be positive."};
                    const rate = vol / time;
                    return { flowRateMlHr: rate.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Total Volume: ${values.totalVolume} mL<br>
                        2. Total Time: ${values.totalTimeHours} hours<br>
                        3. Formula: Total Volume / Total Time<br>
                        4. Calculation: ${values.totalVolume} mL / ${values.totalTimeHours} hours = <strong class="results-strong-text-color">${result.flowRateMlHr} mL/hr</strong>
                    `;
                }
            },
            {
                id: "ivFlowRateGttMin",
                name: "IV Flow Rate (gtt/min)",
                inputs: [
                    { id: "totalVolumeGtt", label: "Total Volume", type: "number", unit: "mL", placeholder: "e.g., 200" },
                    { id: "totalTimeMinutes", label: "Total Time", type: "number", unit: "minutes", placeholder: "e.g., 90" },
                    { id: "dropFactor", label: "Drop Factor", type: "number", unit: "gtt/mL", placeholder: "e.g., 15 (Macro) or 60 (Micro)" }
                ],
                outputs: [{ id: "flowRateGttMin", label: "Flow Rate", unit: "gtt/min" }],
                formulaText: "Flow Rate (gtt/min) = (Total Volume (mL) * Drop Factor (gtt/mL)) / Total Time (minutes)",
                calculate: function(values) {
                    const vol = parseFloat(values.totalVolumeGtt);
                    const time = parseFloat(values.totalTimeMinutes);
                    const factor = parseFloat(values.dropFactor);
                    if (isNaN(vol) || isNaN(time) || isNaN(factor) || time === 0) return { error: "Invalid input. Ensure fields are numeric and time is not zero." };
                    if (vol < 0 || time < 0 || factor < 0) return { error: "Inputs must be positive."};
                    const rate = (vol * factor) / time;
                    return { flowRateGttMin: Math.round(rate) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Total Volume: ${values.totalVolumeGtt} mL<br>
                        2. Total Time: ${values.totalTimeMinutes} minutes<br>
                        3. Drop Factor: ${values.dropFactor} gtt/mL<br>
                        4. Formula: (Total Volume * Drop Factor) / Total Time<br>
                        5. Calculation: (${values.totalVolumeGtt} mL * ${values.dropFactor} gtt/mL) / ${values.totalTimeMinutes} min = <strong class="results-strong-text-color">${result.flowRateGttMin} gtt/min</strong> (rounded)
                    `;
                }
            }
        ]
    },
    {
        category: "Adult Health & Med-Surg",
        categoryIcon: "🧑‍⚕️",
        calculators: [
            {
                id: "bmi",
                name: "Body Mass Index (BMI)",
                visualizationType: "linearGauge",
                visualizationParams: {
                    unit: 'kg/m²',
                    ranges: [
                        { label: 'Underweight', max: 18.5, color: '#a855f7' }, // purple-500
                        { label: 'Normal', max: 24.9, color: '#22c55e' }, // green-500
                        { label: 'Overweight', max: 29.9, color: '#f59e0b' }, // amber-500
                        { label: 'Obesity I', max: 34.9, color: '#ef4444' }, // red-500
                        { label: 'Obesity II', max: 39.9, color: '#d946ef' }, // fuchsia-500
                        { label: 'Obesity III', max: 50, color: '#dc2626' } // red-600
                    ],
                    displayMin: 10,
                    displayMax: 50
                },
                inputs: [
                    { id: "weightKg", label: "Weight", type: "number", unit: "kg", placeholder: "e.g., 70" },
                    { id: "heightCm", label: "Height", type: "number", unit: "cm", placeholder: "e.g., 175" }
                ],
                outputs: [{ id: "bmiValue", label: "BMI", unit: "kg/m²" }],
                formulaText: "BMI = Weight (kg) / (Height (m))²",
                calculate: function(values) {
                    const weight = parseFloat(values.weightKg);
                    const heightCm = parseFloat(values.heightCm);
                    if (isNaN(weight) || isNaN(heightCm) || heightCm === 0) return { error: "Invalid input. Ensure fields are numeric and height is not zero." };
                    if (weight <= 0 || heightCm <= 0) return { error: "Weight and height must be positive values."};
                    const heightM = heightCm / 100;
                    const bmi = weight / (heightM * heightM);
                    return { bmiValue: bmi.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    const heightM = parseFloat(values.heightCm) / 100;
                    return `
                        1. Weight: ${values.weightKg} kg<br>
                        2. Height: ${values.heightCm} cm = ${heightM.toFixed(2)} m<br>
                        3. Formula: Weight (kg) / (Height (m))²<br>
                        4. Calculation: ${values.weightKg} kg / (${heightM.toFixed(2)} m)² = <strong class="results-strong-text-color">${result.bmiValue} kg/m²</strong>
                    `;
                },
                interpretResult: function(result) {
                    const bmi = parseFloat(result.bmiValue);
                    if (bmi < 18.5) return "Category: Underweight. Normal Range: 18.5 - 24.9 kg/m²";
                    if (bmi < 25) return "Category: Normal weight. Normal Range: 18.5 - 24.9 kg/m²";
                    if (bmi < 30) return "Category: Overweight. Normal Range: 18.5 - 24.9 kg/m²";
                    if (bmi < 35) return "Category: Obesity Class I. Normal Range: 18.5 - 24.9 kg/m²";
                    if (bmi < 40) return "Category: Obesity Class II. Normal Range: 18.5 - 24.9 kg/m²";
                    return "Category: Obesity Class III. Normal Range: 18.5 - 24.9 kg/m²";
                }
            },
            {
                id: "fluidBalance",
                name: "Fluid Balance (I&O)",
                visualizationType: "barChart",
                inputs: [
                    { id: "intakeItems", label: "Intake Items", type: "dynamicList", listName: "Intake" },
                    { id: "outputItems", label: "Output Items", type: "dynamicList", listName: "Output" }
                ],
                outputs: [
                    { id: "totalIntake", label: "Total Intake", unit: "mL" },
                    { id: "totalOutput", label: "Total Output", unit: "mL" },
                    { id: "finalBalance", label: "Final Fluid Balance", unit: "mL" }
                ],
                formulaText: "Fluid Balance = Total Intake - Total Output",
                calculate: function(values) {
                    let totalIntake = 0;
                    (values.intakeItems || []).forEach(item => totalIntake += parseFloat(item.amount || 0));
                    let totalOutput = 0;
                    (values.outputItems || []).forEach(item => totalOutput += parseFloat(item.amount || 0));
                    const finalBalance = totalIntake - totalOutput;
                    return {
                        totalIntake: totalIntake.toFixed(0),
                        totalOutput: totalOutput.toFixed(0),
                        finalBalance: finalBalance.toFixed(0)
                    };
                },
                getCalculationBreakdown: function(values, result) {
                    let intakeBreakdown = (values.intakeItems || []).map(item => `&nbsp;&nbsp;&nbsp;&nbsp;- ${item.description || 'Unnamed'}: ${item.amount || 0} mL`).join('<br>');
                    let outputBreakdown = (values.outputItems || []).map(item => `&nbsp;&nbsp;&nbsp;&nbsp;- ${item.description || 'Unnamed'}: ${item.amount || 0} mL`).join('<br>');
                    return `
                        1. Total Intake Items:<br>${intakeBreakdown || '&nbsp;&nbsp;&nbsp;&nbsp;- No intake items entered'}<br>
                           <strong class="results-strong-text-color">Total Intake: ${result.totalIntake} mL</strong><br><br>
                        2. Total Output Items:<br>${outputBreakdown || '&nbsp;&nbsp;&nbsp;&nbsp;- No output items entered'}<br>
                           <strong class="results-strong-text-color">Total Output: ${result.totalOutput} mL</strong><br><br>
                        3. Formula: Total Intake - Total Output<br>
                        4. Calculation: ${result.totalIntake} mL - ${result.totalOutput} mL = <strong class="results-strong-text-color">${result.finalBalance >= 0 ? '+' : ''}${result.finalBalance} mL</strong>
                    `;
                }
            },
            {
                id: "creatinineClearanceCGAdult",
                name: "Creatinine Clearance (Cockcroft-Gault)",
                inputs: [
                    { id: "ageYearsCG", label: "Age", type: "number", unit: "years", placeholder: "e.g., 65" },
                    { id: "weightCrClCG", label: "Weight (Mass)", type: "number", unit: "kg", placeholder: "e.g., 70" },
                    { id: "serumCreatinineCG", label: "Serum Creatinine", type: "number", unit: "mg/dL", placeholder: "e.g., 1.2" },
                    { id: "genderCG", label: "Gender", type: "select", options: [ {value: "male", text: "Male"}, {value: "female", text: "Female"} ] }
                ],
                outputs: [{ id: "crclValueCG", label: "Creatinine Clearance", unit: "mL/min" }],
                formulaText: "C_Cr = ((140 - Age) * Mass (kg)) / (72 * Serum Creatinine (mg/dL)) (x 0.85 for females)",
                calculate: function(values) {
                    const age = parseInt(values.ageYearsCG);
                    const weight = parseFloat(values.weightCrClCG);
                    const cr = parseFloat(values.serumCreatinineCG);
                    if (isNaN(age) || isNaN(weight) || isNaN(cr) || cr === 0) return { error: "Invalid input. Ensure fields are numeric and Serum Creatinine is not zero." };
                    if (age <=0 || weight <=0 || cr <=0) return { error: "Age, weight, and serum creatinine must be positive values."};

                    let crcl = ((140 - age) * weight) / (72 * cr);
                    if (values.genderCG === "female") {
                        crcl *= 0.85;
                    }
                    return { crclValueCG: crcl.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    let femaleMultiplier = values.genderCG === "female" ? " * 0.85 (for female)" : "";
                    return `
                        1. Age: ${values.ageYearsCG} years<br>
                        2. Weight (Mass): ${values.weightCrClCG} kg<br>
                        3. Serum Creatinine: ${values.serumCreatinineCG} mg/dL<br>
                        4. Gender: ${values.genderCG.charAt(0).toUpperCase() + values.genderCG.slice(1)}<br>
                        5. Formula: ((140 - Age) * Mass) / (72 * Serum Creatinine)${femaleMultiplier}<br>
                        6. Calculation: ((140 - ${values.ageYearsCG}) * ${values.weightCrClCG}) / (72 * ${values.serumCreatinineCG})${femaleMultiplier} = <strong class="results-strong-text-color">${result.crclValueCG} mL/min</strong>
                    `;
                },
                interpretResult: function(result) {
                    const crcl = parseFloat(result.crclValueCG);
                    let interpretation = `CrCl: ${crcl.toFixed(1)} mL/min. `;
                    if (crcl < 15) interpretation += "Stage 5 CKD (Kidney Failure).";
                    else if (crcl < 30) interpretation += "Stage 4 CKD (Severe GFR Decrease).";
                    else if (crcl < 60) interpretation += "Stage 3 CKD (Moderate GFR Decrease).";
                    else if (crcl < 90) interpretation += "Stage 2 CKD (Mild GFR Decrease, if other kidney damage signs).";
                    else interpretation += "Normal or Stage 1 CKD (if other kidney damage signs).";
                    return interpretation + " Typical Normal GFR: >90 mL/min/1.73m² (Cockcroft-Gault estimates CrCl, which approximates GFR).";
                }
            },
            {
                id: "anionGapGeneralAdult",
                name: "Anion Gap",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: 'mEq/L',
                    maxScore: 25,
                    ranges: [
                        { till: 2, label: 'Low', color: '#f59e0b' },
                        { till: 12, label: 'Normal', color: '#22c55e' },
                        { till: 25, label: 'High', color: '#ef4444' }
                    ]
                },
                inputs: [
                    { id: "sodiumAG", label: "Sodium (Na⁺)", type: "number", unit: "mEq/L", placeholder: "e.g., 140" },
                    { id: "chlorideAG", label: "Chloride (Cl⁻)", type: "number", unit: "mEq/L", placeholder: "e.g., 100" },
                    { id: "bicarbonateAG", label: "Bicarbonate (HCO₃⁻)", type: "number", unit: "mEq/L", placeholder: "e.g., 22" }
                ],
                outputs: [{ id: "anionGapValue", label: "Anion Gap", unit: "mEq/L" }],
                formulaText: "Anion Gap = [Na⁺] - ([Cl⁻] + [HCO₃⁻])",
                calculate: function(values) {
                    const na = parseFloat(values.sodiumAG);
                    const cl = parseFloat(values.chlorideAG);
                    const hco3 = parseFloat(values.bicarbonateAG);
                    if (isNaN(na) || isNaN(cl) || isNaN(hco3)) return { error: "Invalid input. Ensure all fields are numeric." };
                    const gap = na - (cl + hco3);
                    return { anionGapValue: gap.toFixed(0) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Sodium (Na⁺): ${values.sodiumAG} mEq/L<br>
                        2. Chloride (Cl⁻): ${values.chlorideAG} mEq/L<br>
                        3. Bicarbonate (HCO₃⁻): ${values.bicarbonateAG} mEq/L<br>
                        4. Formula: [Na⁺] - ([Cl⁻] + [HCO₃⁻])<br>
                        5. Calculation: ${values.sodiumAG} - (${values.chlorideAG} + ${values.bicarbonateAG}) = <strong class="results-strong-text-color">${result.anionGapValue} mEq/L</strong>
                    `;
                },
                interpretResult: function(result) {
                    const gap = parseFloat(result.anionGapValue);
                    if (gap > 12) return "Interpretation: High Anion Gap. Normal Range: 3-11 mEq/L (may vary slightly by lab).";
                    if (gap < 3) return "Interpretation: Low Anion Gap. Normal Range: 3-11 mEq/L.";
                    return "Interpretation: Normal Anion Gap. Normal Range: 3-11 mEq/L.";
                }
            }
        ]
    },
    {
        category: "Pediatric Nursing",
        categoryIcon: "👶",
        calculators: [
            {
                id: "pediatricDosage",
                name: "Weight-Based Dosage (Peds)",
                inputs: [
                    { id: "prescribedDosePerKg", label: "Prescribed Dose", type: "number", unit: "mg/kg/day", placeholder: "e.g., 40" },
                    { id: "weightPeds", label: "Weight", type: "number", unit: "kg", placeholder: "e.g., 18" },
                    { id: "dosesPerDay", label: "Number of Doses per day", type: "number", unit: "doses", placeholder: "e.g., 2" }
                ],
                outputs: [
                    { id: "totalDailyDose", label: "Total Daily Dose", unit: "mg" },
                    { id: "singleDose", label: "Single Dose", unit: "mg" }
                ],
                formulaText: "Total Daily Dose = Prescribed (mg/kg/day) * Weight (kg); Single Dose = Total Daily Dose / Doses per day",
                calculate: function(values) {
                    const doseKgDay = parseFloat(values.prescribedDosePerKg);
                    const weight = parseFloat(values.weightPeds);
                    const numDoses = parseInt(values.dosesPerDay);
                    if (isNaN(doseKgDay) || isNaN(weight) || isNaN(numDoses) || numDoses === 0) return { error: "Invalid input. Ensure fields are numeric and doses/day is not zero." };
                    if (doseKgDay <= 0 || weight <= 0 || numDoses <= 0) return { error: "All inputs must be positive values."};
                    const totalDaily = doseKgDay * weight;
                    const single = totalDaily / numDoses;
                    return {
                        totalDailyDose: totalDaily.toFixed(2),
                        singleDose: single.toFixed(2)
                    };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Prescribed Dose: ${values.prescribedDosePerKg} mg/kg/day<br>
                        2. Weight: ${values.weightPeds} kg<br>
                        3. Number of Doses per day: ${values.dosesPerDay}<br><br>
                        4. Calculate Total Daily Dose:<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Formula: Prescribed Dose * Weight<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Calculation: ${values.prescribedDosePerKg} mg/kg/day * ${values.weightPeds} kg = <strong class="results-strong-text-color">${result.totalDailyDose} mg/day</strong><br><br>
                        5. Calculate Single Dose:<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Formula: Total Daily Dose / Number of Doses per day<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Calculation: ${result.totalDailyDose} mg/day / ${values.dosesPerDay} doses = <strong class="results-strong-text-color">${result.singleDose} mg/dose</strong>
                    `;
                }
            },
            {
                id: "maintenanceFluidsPeds",
                name: "Maintenance Fluid (Holliday-Segar)",
                inputs: [
                    { id: "weightFluidsPeds", label: "Weight", type: "number", unit: "kg", placeholder: "e.g., 15" }
                ],
                outputs: [
                    { id: "total24hrFluid", label: "Total 24-hour Fluid Need", unit: "mL" },
                    { id: "hourlyRateFluid", label: "Hourly Rate", unit: "mL/hr" }
                ],
                formulaText: "100mL/kg for 1st 10kg; 50mL/kg for next 10kg (11-20kg); 20mL/kg for each kg >20kg.",
                calculate: function(values) {
                    const weight = parseFloat(values.weightFluidsPeds);
                    if (isNaN(weight) || weight <= 0) return { error: "Invalid input. Weight must be a positive number." };

                    let fluid = 0;
                    if (weight <= 10) {
                        fluid = weight * 100;
                    } else if (weight <= 20) {
                        fluid = (10 * 100) + ((weight - 10) * 50);
                    } else {
                        fluid = (10 * 100) + (10 * 50) + ((weight - 20) * 20);
                    }
                    const hourlyRate = fluid / 24;
                    return {
                        total24hrFluid: fluid.toFixed(0),
                        hourlyRateFluid: hourlyRate.toFixed(1)
                    };
                },
                getCalculationBreakdown: function(values, result) {
                    const weight = parseFloat(values.weightFluidsPeds);
                    let breakdown = `1. Weight: ${weight} kg<br><br>2. Calculation Steps (Holliday-Segar Method):<br>`;
                    let fluidCalc = "";
                    if (weight <= 10) {
                        fluidCalc = `&nbsp;&nbsp;&nbsp;&nbsp;- First ${weight.toFixed(1)} kg * 100 mL/kg = ${(weight * 100).toFixed(0)} mL<br>`;
                    } else if (weight <= 20) {
                        fluidCalc = `&nbsp;&nbsp;&nbsp;&nbsp;- First 10 kg: 10 kg * 100 mL/kg = 1000 mL<br>`;
                        fluidCalc += `&nbsp;&nbsp;&nbsp;&nbsp;- Next ${ (weight - 10).toFixed(1) } kg (up to 20kg): ${(weight - 10).toFixed(1)} kg * 50 mL/kg = ${((weight - 10) * 50).toFixed(0)} mL<br>`;
                    } else {
                        fluidCalc = `&nbsp;&nbsp;&nbsp;&nbsp;- First 10 kg: 10 kg * 100 mL/kg = 1000 mL<br>`;
                        fluidCalc += `&nbsp;&nbsp;&nbsp;&nbsp;- Next 10 kg (11-20kg): 10 kg * 50 mL/kg = 500 mL<br>`;
                        fluidCalc += `&nbsp;&nbsp;&nbsp;&nbsp;- Remaining ${ (weight - 20).toFixed(1) } kg: ${(weight - 20).toFixed(1)} kg * 20 mL/kg = ${((weight - 20) * 20).toFixed(0)} mL<br>`;
                    }
                    breakdown += fluidCalc;
                    breakdown += `<br>3. Total 24-hour Fluid Need: <strong class="results-strong-text-color">${result.total24hrFluid} mL</strong><br>`;
                    breakdown += `4. Hourly Rate: ${result.total24hrFluid} mL / 24 hours = <strong class="results-strong-text-color">${result.hourlyRateFluid} mL/hr</strong>`;
                    return breakdown;
                }
            },
            {
                id: "minUrineOutputPeds",
                name: "Minimum Urine Output (Peds)",
                inputs: [
                    { id: "weightUrinePeds", label: "Weight", type: "number", unit: "kg", placeholder: "e.g., 12" },
                    { id: "shiftDuration", label: "Duration of Shift", type: "number", unit: "hours", placeholder: "e.g., 8" }
                ],
                outputs: [{ id: "minUrineOutput", label: "Minimum Urine Output for Shift", unit: "mL" }],
                formulaText: "Min Urine Output (mL) = Weight (kg) * 1 mL/kg/hr * Duration (hours) (typical for older children; 1.5-2 mL/kg/hr for infants)",
                calculate: function(values) {
                    const weight = parseFloat(values.weightUrinePeds);
                    const duration = parseFloat(values.shiftDuration);
                    const ratePerKgHr = 1;
                    if (isNaN(weight) || isNaN(duration)) return { error: "Invalid input. Ensure fields are numeric." };
                    if (weight <= 0 || duration <= 0) return { error: "Weight and duration must be positive values."};
                    const output = weight * ratePerKgHr * duration;
                    return { minUrineOutput: output.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    const ratePerKgHr = 1;
                    return `
                        1. Weight: ${values.weightUrinePeds} kg<br>
                        2. Duration of Shift: ${values.shiftDuration} hours<br>
                        3. Assumed Minimum Rate: ${ratePerKgHr} mL/kg/hr (Note: Infants may require 1.5-2 mL/kg/hr)<br>
                        4. Formula: Weight * Rate * Duration<br>
                        5. Calculation: ${values.weightUrinePeds} kg * ${ratePerKgHr} mL/kg/hr * ${values.shiftDuration} hours = <strong class="results-strong-text-color">${result.minUrineOutput} mL</strong>
                    `;
                }
            }
        ]
    },
    {
        category: "Obstetric Nursing",
        categoryIcon: "🤰",
        calculators: [
            {
                id: "eddNaegeles",
                name: "Estimated Date of Delivery (Naegele's Rule)",
                inputs: [
                    { id: "lmpDate", label: "First Day of Last Menstrual Period (LMP)", type: "date" }
                ],
                outputs: [{ id: "edd", label: "Estimated Date of Delivery (EDD)", unit: "" }],
                formulaText: "EDD = (LMP - 3 Months) + 7 Days + 1 Year",
                calculate: function(values) {
                    const lmp = values.lmpDate;
                    if (!lmp) return { error: "Please select the LMP date."};
                    const lmpDate = new Date(lmp + "T00:00:00");

                    lmpDate.setMonth(lmpDate.getMonth() - 3);
                    lmpDate.setDate(lmpDate.getDate() + 7);
                    lmpDate.setFullYear(lmpDate.getFullYear() + 1);
                    
                    return { edd: lmpDate.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }) };
                },
                getCalculationBreakdown: function(values, result) {
                    const lmpDate = new Date(values.lmpDate + "T00:00:00");
                    const initialLmpString = lmpDate.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });

                    const step1Date = new Date(lmpDate);
                    step1Date.setMonth(step1Date.getMonth() - 3);
                    const step1String = step1Date.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });

                    const step2Date = new Date(step1Date);
                    step2Date.setDate(step2Date.getDate() + 7);
                    const step2String = step2Date.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
                    
                    return `
                        1. First Day of LMP: ${initialLmpString}<br>
                        2. Subtract 3 Months: ${initialLmpString} - 3 Months = ${step1String}<br>
                        3. Add 7 Days: ${step1String} + 7 Days = ${step2String}<br>
                        4. Add 1 Year: ${step2String} + 1 Year = <strong class="results-strong-text-color">${result.edd}</strong>
                    `;
                }
            },
            {
                id: "apgarScore",
                name: "APGAR Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 10,
                    ranges: [
                        { till: 3, label: 'Severely Depressed', color: '#ef4444' },
                        { till: 6, label: 'Mildly Depressed', color: '#f59e0b' },
                        { till: 10, label: 'Normal', color: '#22c55e' }
                    ]
                },
                inputs: [
                    { id: "appearance", label: "Appearance (Color)", type: "select", options: [ {value: "2", text: "Completely Pink (2)"}, {value: "1", text: "Body Pink, Extremities Blue (Acrocyanosis) (1)"}, {value: "0", text: "Blue, Pale (0)"} ] },
                    { id: "pulse", label: "Pulse (Heart Rate)", type: "select", options: [ {value: "2", text: "> 100 bpm (2)"}, {value: "1", text: "< 100 bpm (1)"}, {value: "0", text: "Absent (0)"} ] },
                    { id: "grimace", label: "Grimace (Reflex Irritability)", type: "select", options: [ {value: "2", text: "Cries, Coughs, Sneezes (Vigorous) (2)"}, {value: "1", text: "Grimace (1)"}, {value: "0", text: "No Response (0)"} ] },
                    { id: "activity", label: "Activity (Muscle Tone)", type: "select", options: [ {value: "2", text: "Active Motion (Well Flexed) (2)"}, {value: "1", text: "Some Flexion of Extremities (1)"}, {value: "0", text: "Limp, Flaccid (0)"} ] },
                    { id: "respirationApgar", label: "Respiration (Breathing Effort)", type: "select", options: [ {value: "2", text: "Good, Strong Cry (2)"}, {value: "1", text: "Slow, Irregular, Weak Cry (1)"}, {value: "0", text: "Absent (0)"} ] }
                ],
                outputs: [{ id: "totalApgar", label: "Total APGAR Score", unit: "/ 10" }],
                formulaText: "Sum of scores for Appearance, Pulse, Grimace, Activity, and Respiration.",
                calculate: function(values) {
                    const score = parseInt(values.appearance || 0) + parseInt(values.pulse || 0) + parseInt(values.grimace || 0) + parseInt(values.activity || 0) + parseInt(values.respirationApgar || 0);
                    return { totalApgar: score };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Appearance: ${values.appearance} points<br>
                        2. Pulse: ${values.pulse} points<br>
                        3. Grimace: ${values.grimace} points<br>
                        4. Activity: ${values.activity} points<br>
                        5. Respiration: ${values.respirationApgar} points<br>
                        6. Total Score: ${values.appearance} + ${values.pulse} + ${values.grimace} + ${values.activity} + ${values.respirationApgar} = <strong class="results-strong-text-color">${result.totalApgar}</strong>
                    `;
                },
                interpretResult: function(result) {
                    const score = parseInt(result.totalApgar);
                    if (score >= 7) return "Interpretation: Normal (7-10). Routine care.";
                    if (score >= 4) return "Interpretation: Mildly Depressed (4-6). Some assistance for breathing may be required.";
                    return "Interpretation: Severely Depressed (0-3). Immediate resuscitation required.";
                }
            },
            {
                id: "bishopScore",
                name: "Bishop Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 13,
                    ranges: [
                        { till: 5, label: 'Unfavorable', color: '#ef4444' },
                        { till: 7, label: 'Moderately Favorable', color: '#f59e0b' },
                        { till: 13, label: 'Favorable', color: '#22c55e' }
                    ]
                },
                inputs: [
                    { id: "dilation", label: "Dilation (cm)", type: "select", options: [ {value: "0", text: "Closed (0)"}, {value: "1", text: "1-2 cm (1)"}, {value: "2", text: "3-4 cm (2)"}, {value: "3", text: "≥ 5 cm (3)"} ] },
                    { id: "effacement", label: "Effacement (%)", type: "select", options: [ {value: "0", text: "0-30% (0)"}, {value: "1", text: "40-50% (1)"}, {value: "2", text: "60-70% (2)"}, {value: "3", text: "≥ 80% (3)"} ] },
                    { id: "station", label: "Fetal Station", type: "select", options: [ {value: "0", text: "-3 (0)"}, {value: "1", text: "-2 (1)"}, {value: "2", text: "-1, 0 (2)"}, {value: "3", text: "+1, +2 (3)"} ] },
                    { id: "consistency", label: "Cervical Consistency", type: "select", options: [ {value: "0", text: "Firm (0)"}, {value: "1", text: "Medium (1)"}, {value: "2", text: "Soft (2)"} ] },
                    { id: "position", label: "Cervical Position", type: "select", options: [ {value: "0", text: "Posterior (0)"}, {value: "1", text: "Mid-position (1)"}, {value: "2", text: "Anterior (2)"} ] }
                ],
                outputs: [{ id: "totalBishop", label: "Total Bishop Score", unit: "/ 13" }],
                formulaText: "Sum of scores for Dilation, Effacement, Station, Consistency, and Position.",
                calculate: function(values) {
                    const score = parseInt(values.dilation || 0) + parseInt(values.effacement || 0) + parseInt(values.station || 0) + parseInt(values.consistency || 0) + parseInt(values.position || 0);
                    return { totalBishop: score };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Dilation: ${values.dilation} points<br>
                        2. Effacement: ${values.effacement} points<br>
                        3. Station: ${values.station} points<br>
                        4. Consistency: ${values.consistency} points<br>
                        5. Position: ${values.position} points<br>
                        6. Total Score: ${values.dilation} + ${values.effacement} + ${values.station} + ${values.consistency} + ${values.position} = <strong class="results-strong-text-color">${result.totalBishop}</strong>
                    `;
                },
                interpretResult: function(result) {
                    const score = parseInt(result.totalBishop);
                    if (score >= 8) return "Interpretation: Favorable for induction (High likelihood of success).";
                    if (score >= 6) return "Interpretation: Moderately favorable for induction.";
                    return "Interpretation: Unfavorable for induction (Score ≤ 5. Cervical ripening may be considered).";
                }
            }
        ]
    },
    {
        category: "Critical Care (General)",
        categoryIcon: "🩺",
        calculators: [
            {
                id: "mapGeneralCritCare",
                name: "Mean Arterial Pressure (MAP)",
                inputs: [
                    { id: "sbpMap", label: "Systolic Blood Pressure (SBP)", type: "number", unit: "mmHg", placeholder: "e.g., 120" },
                    { id: "dbpMap", label: "Diastolic Blood Pressure (DBP)", type: "number", unit: "mmHg", placeholder: "e.g., 80" }
                ],
                outputs: [{ id: "mapValue", label: "MAP", unit: "mmHg" }],
                formulaText: "MAP = (SBP + 2 * DBP) / 3",
                calculate: function(values) {
                    const sbp = parseFloat(values.sbpMap);
                    const dbp = parseFloat(values.dbpMap);
                    if (isNaN(sbp) || isNaN(dbp)) return { error: "Invalid input. Ensure SBP and DBP are numeric." };
                    if (sbp <= 0 || dbp <= 0) return { error: "SBP and DBP must be positive values."};
                    if (sbp < dbp) return { error: "SBP should typically be greater than or equal to DBP."};
                    const mapVal = (sbp + (2 * dbp)) / 3;
                    return { mapValue: mapVal.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Systolic BP (SBP): ${values.sbpMap} mmHg<br>
                        2. Diastolic BP (DBP): ${values.dbpMap} mmHg<br>
                        3. Formula: (SBP + 2 * DBP) / 3<br>
                        4. Calculation: (${values.sbpMap} + 2 * ${values.dbpMap}) / 3 = <strong class="results-strong-text-color">${result.mapValue} mmHg</strong>
                    `;
                },
                interpretResult: function(result) {
                    const mapVal = parseFloat(result.mapValue);
                    if (mapVal < 65) return "Interpretation: MAP < 65 mmHg may indicate inadequate organ perfusion. Normal Range: 70-100 mmHg (target >65 mmHg in critical care).";
                    return "Interpretation: MAP ≥ 65 mmHg is generally desired for adequate organ perfusion. Normal Range: 70-100 mmHg.";
                }
            },
            {
                id: "gcsGeneralCritCare",
                name: "Glasgow Coma Scale (GCS)",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 15,
                    ranges: [
                        { till: 8, label: 'Severe Injury', color: '#ef4444' },
                        { till: 12, label: 'Moderate Injury', color: '#f59e0b' },
                        { till: 15, label: 'Mild Injury', color: '#22c55e' }
                    ]
                },
                inputs: [
                    { id: "eyeOpeningGCS", label: "Eye Opening Response", type: "select", options: [ {value: "4", text: "Spontaneous (4)"}, {value: "3", text: "To Speech (3)"}, {value: "2", text: "To Pain (2)"}, {value: "1", text: "No Response (1)"} ] },
                    { id: "verbalResponseGCS", label: "Verbal Response", type: "select", options: [ {value: "5", text: "Oriented (5)"}, {value: "4", text: "Confused (4)"}, {value: "3", text: "Inappropriate Words (3)"}, {value: "2", text: "Incomprehensible Sounds (2)"}, {value: "1", text: "No Response (1)"} ] },
                    { id: "motorResponseGCS", label: "Motor Response", type: "select", options: [ {value: "6", text: "Obeys Commands (6)"}, {value: "5", text: "Localizes Pain (5)"}, {value: "4", text: "Withdraws from Pain (4)"}, {value: "3", text: "Abnormal Flexion (Decorticate) (3)"}, {value: "2", text: "Abnormal Extension (Decerebrate) (2)"}, {value: "1", text: "No Response (Flaccid) (1)"} ] }
                ],
                outputs: [{ id: "totalGcs", label: "Total GCS Score", unit: "/ 15" }],
                formulaText: "Sum of scores for Eye Opening, Verbal Response, and Motor Response.",
                calculate: function(values) {
                    const score = parseInt(values.eyeOpeningGCS || 0) + parseInt(values.verbalResponseGCS || 0) + parseInt(values.motorResponseGCS || 0);
                    return { totalGcs: score };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Eye Opening: ${values.eyeOpeningGCS} points<br>
                        2. Verbal Response: ${values.verbalResponseGCS} points<br>
                        3. Motor Response: ${values.motorResponseGCS} points<br>
                        4. Total Score: ${values.eyeOpeningGCS} + ${values.verbalResponseGCS} + ${values.motorResponseGCS} = <strong class="results-strong-text-color">${result.totalGcs}</strong>
                    `;
                },
                interpretResult: function(result) {
                    const score = parseInt(result.totalGcs);
                    if (score <= 8) return "Severity: Severe Head Injury (GCS ≤ 8)";
                    if (score <= 12) return "Severity: Moderate Head Injury (GCS 9-12)";
                    return "Severity: Mild Head Injury (GCS 13-15). Max Score: 15.";
                }
            },
            {
                id: "parklandFormula",
                name: "Parkland Formula (Burn Resuscitation)",
                inputs: [
                    { id: "weightBurn", label: "Weight", type: "number", unit: "kg", placeholder: "e.g., 75" },
                    { id: "tbsa", label: "Total Body Surface Area Burned", type: "number", unit: "%", placeholder: "e.g., 40" }
                ],
                outputs: [
                    { id: "totalFluid24hr", label: "Total Fluid in 24 hrs", unit: "mL" },
                    { id: "fluidFirst8hr", label: "Fluid for First 8 hrs", unit: "mL" },
                    { id: "rateFirst8hr", label: "Rate for First 8 hrs", unit: "mL/hr" },
                    { id: "fluidNext16hr", label: "Fluid for Next 16 hrs", unit: "mL" },
                    { id: "rateNext16hr", label: "Rate for Next 16 hrs", unit: "mL/hr" }
                ],
                formulaText: "Total Fluid (mL) = 4 mL * Weight (kg) * %TBSA. Give 1st half over 8 hrs, 2nd half over next 16 hrs.",
                calculate: function(values) {
                    const weight = parseFloat(values.weightBurn);
                    const tbsa = parseFloat(values.tbsa);
                    if (isNaN(weight) || isNaN(tbsa)) return { error: "Invalid input. Ensure fields are numeric." };
                    if (weight <= 0 || tbsa < 0 || tbsa > 100) return { error: "Weight must be positive. TBSA must be between 0 and 100."};

                    const totalFluid = 4 * weight * tbsa;
                    const first8hrFluid = totalFluid / 2;
                    const next16hrFluid = totalFluid / 2;
                    const rate8hr = first8hrFluid / 8;
                    const rate16hr = next16hrFluid / 16;

                    return {
                        totalFluid24hr: totalFluid.toFixed(0),
                        fluidFirst8hr: first8hrFluid.toFixed(0),
                        rateFirst8hr: rate8hr.toFixed(0),
                        fluidNext16hr: next16hrFluid.toFixed(0),
                        rateNext16hr: rate16hr.toFixed(0)
                    };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Weight: ${values.weightBurn} kg<br>
                        2. %TBSA Burned: ${values.tbsa} %<br><br>
                        3. Total Fluid in 24 hours:<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Formula: 4 mL * Weight (kg) * %TBSA<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Calculation: 4 mL * ${values.weightBurn} kg * ${values.tbsa}% = <strong class="results-strong-text-color">${result.totalFluid24hr} mL</strong><br><br>
                        4. Fluid for First 8 Hours (from time of burn):<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Volume: ${result.totalFluid24hr} mL / 2 = <strong class="results-strong-text-color">${result.fluidFirst8hr} mL</strong><br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Rate: ${result.fluidFirst8hr} mL / 8 hours = <strong class="results-strong-text-color">${result.rateFirst8hr} mL/hr</strong><br><br>
                        5. Fluid for Next 16 Hours:<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Volume: ${result.totalFluid24hr} mL / 2 = <strong class="results-strong-text-color">${result.fluidNext16hr} mL</strong><br>
                            &nbsp;&nbsp;&nbsp;&nbsp;Rate: ${result.fluidNext16hr} mL / 16 hours = <strong class="results-strong-text-color">${result.rateNext16hr} mL/hr</strong>
                    `;
                }
            },
            {
                id: "cpp",
                name: "Cerebral Perfusion Pressure (CPP)",
                inputs: [
                    { id: "mapForCpp", label: "Mean Arterial Pressure (MAP)", type: "number", unit: "mmHg", placeholder: "e.g., 85" },
                    { id: "icp", label: "Intracranial Pressure (ICP)", type: "number", unit: "mmHg", placeholder: "e.g., 15" }
                ],
                outputs: [{ id: "cppValue", label: "CPP", unit: "mmHg" }],
                formulaText: "CPP = MAP - ICP",
                calculate: function(values) {
                    const mapVal = parseFloat(values.mapForCpp);
                    const icpVal = parseFloat(values.icp);
                    if (isNaN(mapVal) || isNaN(icpVal)) return { error: "Invalid input. Ensure MAP and ICP are numeric." };
                    if (mapVal <= 0 || icpVal < 0) return { error: "MAP must be positive, ICP non-negative."};
                    const cppResult = mapVal - icpVal;
                    return { cppValue: cppResult.toFixed(1) };
                },
                getCalculationBreakdown: function(values, result) {
                    return `
                        1. Mean Arterial Pressure (MAP): ${values.mapForCpp} mmHg<br>
                        2. Intracranial Pressure (ICP): ${values.icp} mmHg<br>
                        3. Formula: MAP - ICP<br>
                        4. Calculation: ${values.mapForCpp} mmHg - ${values.icp} mmHg = <strong class="results-strong-text-color">${result.cppValue} mmHg</strong>
                    `;
                },
                interpretResult: function(result) {
                    const cppVal = parseFloat(result.cppValue);
                    let interp = `CPP: ${cppVal.toFixed(1)} mmHg. `;
                    if (cppVal < 50) interp += "Critical: Brain ischemia likely.";
                    else if (cppVal < 60) interp += "Low: Monitor closely, risk of ischemia.";
                    else if (cppVal <= 70) interp += "Target Range: Generally considered adequate.";
                    else interp += "Above typical target; monitor clinical context.";
                    return interp + " Normal ICP: 5-15 mmHg. Target CPP usually 60-70 mmHg.";
                }
            },
            {
                id: "pfRatio",
                name: "PaO₂/FiO₂ Ratio (P/F Ratio)",
                visualizationType: "linearGauge",
                visualizationParams: {
                    unit: '',
                    ranges: [
                        { label: 'Severe ARDS', max: 100, color: '#ef4444' }, // red-500
                        { label: 'Moderate ARDS', max: 200, color: '#f97316' }, // orange-500
                        { label: 'Mild ARDS', max: 300, color: '#f59e0b' }, // amber-500
                        { label: 'Normal', max: 500, color: '#22c55e' } // green-500
                    ],
                    displayMin: 0,
                    displayMax: 500
                },
                inputs: [
                    { id: "pao2", label: "PaO₂ (Arterial Oxygen Partial Pressure)", type: "number", unit: "mmHg", placeholder: "e.g., 90" },
                    { id: "fio2", label: "FiO₂ (Fraction of Inspired Oxygen)", type: "number", unit: "%", placeholder: "e.g., 60 (for 60%)" }
                ],
                outputs: [{ id: "pfRatioValue", label: "P/F Ratio", unit: "" }],
                formulaText: "P/F Ratio = PaO₂ / (FiO₂ / 100)",
                calculate: function(values) {
                    const pao2Val = parseFloat(values.pao2);
                    const fio2Percent = parseFloat(values.fio2);
                    if (isNaN(pao2Val) || isNaN(fio2Percent) || fio2Percent === 0) return { error: "Invalid input. Ensure fields are numeric and FiO₂ is not zero." };
                    if (pao2Val < 0 || fio2Percent < 21 || fio2Percent > 100) return { error: "PaO2 must be non-negative. FiO2 must be between 21% and 100%."};
                    const fio2Decimal = fio2Percent / 100;
                    const ratio = pao2Val / fio2Decimal;
                    return { pfRatioValue: ratio.toFixed(0) };
                },
                getCalculationBreakdown: function(values, result) {
                    const fio2Decimal = parseFloat(values.fio2) / 100;
                    return `
                        1. PaO₂: ${values.pao2} mmHg<br>
                        2. FiO₂: ${values.fio2}% = ${fio2Decimal.toFixed(2)} (as decimal)<br>
                        3. Formula: PaO₂ / FiO₂ (decimal)<br>
                        4. Calculation: ${values.pao2} mmHg / ${fio2Decimal.toFixed(2)} = <strong class="results-strong-text-color">${result.pfRatioValue}</strong>
                    `;
                },
                interpretResult: function(result) {
                    const ratio = parseFloat(result.pfRatioValue);
                    if (ratio <= 100) return "ARDS Severity: Severe (P/F Ratio ≤ 100)";
                    if (ratio <= 200) return "ARDS Severity: Moderate (100 < P/F Ratio ≤ 200)";
                    if (ratio <= 300) return "ARDS Severity: Mild (200 < P/F Ratio ≤ 300)";
                    return "Interpretation: Normal or No ARDS by this criterion (P/F Ratio > 300)";
                }
            }
        ]
    },
    {
        category: "Cardiology",
        categoryIcon: "❤️",
        calculators: [
            {
                id: "ascvdRiskScore", name: "ASCVD Risk Score",
                inputs: [
                    {id: "ageASCVD", label:"Age", type:"number", unit:"years"}, {id: "totalCholesterolASCVD", label:"Total Cholesterol", type:"number", unit:"mg/dL"}, {id:"hdlASCVD", label:"HDL Cholesterol", type:"number", unit:"mg/dL"}
                ],
                outputs: [{id:"ascvdInfo", label:"ASCVD Risk Information"}],
                formulaText: "Complex algorithm including Age, Sex, Race, TC, HDL, SBP, BP Meds, Diabetes, Smoking.",
                infoMessage: "The ASCVD Risk Score is complex and best calculated using a dedicated, validated clinical tool. This calculator provides a general overview of factors.",
                calculate: function(values){ return {info: "Refer to a specialized ACC/AHA ASCVD risk estimator tool for accurate calculation."}; },
                getCalculationBreakdown: function(values,result){ return `This score considers multiple factors: Age (${values.ageASCVD || 'N/A'}), Total Cholesterol (${values.totalCholesterolASCVD || 'N/A'}), HDL (${values.hdlASCVD || 'N/A'}), and others not listed here.`; },
            },
            {
                id: "chadsVascScore", name: "CHA₂DS₂-VASc Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 9,
                    ranges: [
                        { till: 0, label: 'Very Low Risk', color: '#22c55e' },
                        { till: 1, label: 'Low-Mod. Risk', color: '#f59e0b' },
                        { till: 9, label: 'Mod-High Risk', color: '#ef4444' }
                    ]
                },
                inputs: [
                    {id: "chf", label:"Congestive Heart Failure", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "hypertension", label:"Hypertension", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "ageChads", label:"Age", type:"select", options:[{value:"0", text:"<65 (0)"},{value:"1", text:"65-74 (1)"},{value:"2", text:">=75 (2)"}]},
                    {id: "diabetes", label:"Diabetes Mellitus", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "strokeTia", label:"Prior Stroke/TIA/Thromboembolism", type:"select", options:[{value:"0", text:"No (0)"},{value:"2", text:"Yes (2)"}]},
                    {id: "vascularDisease", label:"Vascular Disease (MI, PAD, Aortic Plaque)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "sexCategory", label:"Sex Category (Female)", type:"select", options:[{value:"0", text:"Male (0)"},{value:"1", text:"Female (1)"}]},
                ],
                outputs: [{id:"chadsVascTotal", label:"CHA₂DS₂-VASc Score", unit: "/ 9"}],
                formulaText: "C(1) H(1) A₂(2) D(1) S₂(2) V(1) A(1) Sc(1). Sum of points.",
                calculate: function(values){ const s = parseInt(values.chf||0)+parseInt(values.hypertension||0)+parseInt(values.ageChads||0)+parseInt(values.diabetes||0)+parseInt(values.strokeTia||0)+parseInt(values.vascularDisease||0)+parseInt(values.sexCategory||0); return {chadsVascTotal: s};},
                getCalculationBreakdown: function(values,result){ return `CHF: ${values.chf||0}, HTN: ${values.hypertension||0}, Age: ${values.ageChads||0}, DM: ${values.diabetes||0}, Stroke/TIA: ${values.strokeTia||0}, Vasc Dz: ${values.vascularDisease||0}, Sex (Female): ${values.sexCategory||0}.<br>Total = <strong class="results-strong-text-color">${result.chadsVascTotal}</strong>`; },
                interpretResult: function(result, values){ const s = result.chadsVascTotal; if(s===0) return "Risk: Very Low. Consider no antithrombotic therapy."; if(s===1 && values.sexCategory === "0" /* Male */) return "Risk: Low. Consider OAC or Aspirin or No therapy."; if(s===1 && values.sexCategory === "1" /* Female */) return "Risk: Low-Moderate. OAC should be considered."; if(s>=2) return "Risk: Moderate-High. Oral anticoagulation (OAC) recommended."; return "Consider anticoagulation based on score.";}
            },
            {
                id: "correctedQT", name: "Corrected QT Interval (QTc - Bazett)",
                inputs: [
                    {id: "qtInterval", label:"QT Interval", type:"number", unit:"sec", placeholder:"e.g., 0.40"},
                    {id: "rrInterval", label:"RR Interval", type:"number", unit:"sec", placeholder:"e.g., 1.0"}
                ],
                outputs: [{id:"qtcValue", label:"QTc (Bazett)", unit:"ms"}],
                formulaText: "QTc = QT Interval / √(RR Interval)",
                calculate: function(values){ const qt = parseFloat(values.qtInterval); const rr = parseFloat(values.rrInterval); if(isNaN(qt) || isNaN(rr) || rr <= 0) return {error: "Invalid QT or RR interval."}; const qtc = (qt / Math.sqrt(rr)) * 1000; return {qtcValue: qtc.toFixed(0)};},
                getCalculationBreakdown: function(values,result){ return `QT: ${values.qtInterval}s, RR: ${values.rrInterval}s.<br>QTc = ${values.qtInterval} / √${values.rrInterval} = <strong class="results-strong-text-color">${result.qtcValue} ms</strong>`; },
                interpretResult: function(result){ const qtc = parseFloat(result.qtcValue); if(qtc > 440 && qtc <= 460) return "Borderline QTc (Male >440ms, Female >460ms is often considered prolonged)."; if(qtc > 460) return "Prolonged QTc. Risk of Torsades de Pointes. Normal: <440ms (males), <460ms (females)."; return "Normal QTc.";}
            },
            {
                id: "mapCardio", name: "Mean Arterial Pressure (MAP)",
                inputs: [
                    { id: "sbpMapCardio", label: "Systolic Blood Pressure (SBP)", type: "number", unit: "mmHg", placeholder: "e.g., 120" },
                    { id: "dbpMapCardio", label: "Diastolic Blood Pressure (DBP)", type: "number", unit: "mmHg", placeholder: "e.g., 80" }
                ],
                outputs: [{ id: "mapValueCardio", label: "MAP", unit: "mmHg" }],
                formulaText: "MAP = (SBP + 2 * DBP) / 3",
                calculate: function(values){ const sbp = parseFloat(values.sbpMapCardio); const dbp = parseFloat(values.dbpMapCardio); if(isNaN(sbp)||isNaN(dbp)||sbp<=0||dbp<=0||sbp<dbp) return {error:"Invalid BP"}; return {mapValueCardio:((sbp+2*dbp)/3).toFixed(1)};},
                getCalculationBreakdown: function(values,r){ return `SBP: ${values.sbpMapCardio}, DBP: ${values.dbpMapCardio}.<br>(${values.sbpMapCardio} + 2*${values.dbpMapCardio})/3 = <strong class="results-strong-text-color">${r.mapValueCardio} mmHg</strong>`; },
                interpretResult: function(r){ const map = parseFloat(r.mapValueCardio); if (map < 65) return "MAP < 65 mmHg may indicate inadequate organ perfusion."; return "MAP ≥ 65 mmHg generally desired.";}
            }
        ]
    },
    {
        category: "Pulmonology & Critical Care", categoryIcon: "🫁",
        calculators: [
            {id: "apacheIIScore", name: "APACHE II Score", inputs: [{id:"apacheParam1", label:"Sample APACHE Parameter", type:"text"}], outputs:[{id:"apacheIIInfo", label:"APACHE II Score Information"}], infoMessage:"APACHE II is a complex ICU scoring system. Use a dedicated validated tool.", formulaText:"Score based on 12 physiological variables, age, and chronic health.", calculate: function(v){return {info:"Refer to specialized tool for APACHE II."}}, getCalculationBreakdown: function(v,r){ return "Requires multiple physiological inputs (temp, MAP, HR, RR, O2, pH, Na, K, Cr, Hct, WBC, GCS), age, and chronic health status.";}},
            {id: "curb65Score", name: "CURB-65 Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 5,
                    ranges: [
                        { till: 1, label: 'Low Severity', color: '#22c55e' },
                        { till: 2, label: 'Mod. Severity', color: '#f59e0b' },
                        { till: 5, label: 'High Severity', color: '#ef4444' }
                    ]
                },
                inputs: [
                    {id: "confusionCURB", label:"Confusion (new)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "bunCURB", label:"BUN", type:"number", unit:"mg/dL", placeholder:">19 mg/dL is 1 point"},
                    {id: "rrCURB", label:"Respiratory Rate", type:"number", unit:"breaths/min", placeholder:">=30 is 1 point"},
                    {id: "bpCURB", label:"Blood Pressure (SBP<90 or DBP≤60)", type:"select", options:[{value:"0", text:"Normal (0)"},{value:"1", text:"Low (1)"}]},
                    {id: "ageCURB", label:"Age ≥ 65 years", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                ], outputs:[{id:"curb65Total", label:"CURB-65 Score", unit: "/ 5"}], formulaText:"C(1) U(1) R(1) B(1) 65(1). Sum points.",
                calculate: function(v){ let s=0; s+=parseInt(v.confusionCURB||0); if(parseFloat(v.bunCURB)>19)s+=1; if(parseInt(v.rrCURB)>=30)s+=1; s+=parseInt(v.bpCURB||0); s+=parseInt(v.ageCURB||0); if(v.bunCURB===''||isNaN(parseFloat(v.bunCURB)) || v.rrCURB===''||isNaN(parseInt(v.rrCURB))) return {error:"BUN and Respiratory Rate are required."}; return {curb65Total:s}; },
                getCalculationBreakdown: function(v,r){ return `Confusion: ${v.confusionCURB||0}, Urea(BUN>19): ${parseFloat(v.bunCURB)>19?1:0}, RR(≥30): ${parseInt(v.rrCURB)>=30?1:0}, BP(low): ${v.bpCURB||0}, Age(≥65): ${v.ageCURB||0}.<br>Total = <strong class="results-strong-text-color">${r.curb65Total}</strong>`;},
                interpretResult:function(r){ const s = r.curb65Total; if(s<=1) return "Low severity (0-1), consider outpatient."; if(s===2) return "Moderate severity (2), consider hospital admission."; return "High severity (≥3), urgent hospital admission, consider ICU.";}},
            {id: "percRule", name: "PERC Rule (PE Rule-out Criteria)",
                inputs: [
                    {id: "agePERC", label:"Age ≥ 50 years?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "hrPERC", label:"Heart rate ≥ 100 bpm?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "o2SatPERC", label:"O₂ saturation on room air < 95%?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "vteHistoryPERC", label:"Prior VTE history?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "surgeryTraumaPERC", label:"Recent surgery/trauma (last 4 wks)?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "hemoptysisPERC", label:"Hemoptysis?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "estrogenPERC", label:"Exogenous estrogen use?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                    {id: "legSwellingPERC", label:"Unilateral leg swelling?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]},
                ], outputs:[{id:"percOutcome", label:"PERC Rule Outcome"}], formulaText:"If ALL criteria are 'No', PE is less likely in low-risk patients.",
                calculate: function(v){const criteriaNotMet = Object.values(v).some(val => val === "yes"); return {percOutcome: criteriaNotMet ? "One or more criteria met (PERC rule CANNOT rule out PE)" : "All criteria NOT met (PE less likely if pre-test probability is low)"};},
                getCalculationBreakdown: function(v,r){ let breakdown = "Criteria Check:<br>"; for(const key in v) { breakdown += `${key.replace('PERC','')} : ${v[key]}<br>`; } breakdown += `<strong class="results-strong-text-color">${r.percOutcome}</strong>`; return breakdown;},
                interpretResult:function(r){ return "This rule is for LOW-RISK patients. If PE cannot be ruled out by PERC, further testing (e.g., D-dimer, CTPA) may be needed.";}},
            {id: "sirsCriteria", name: "SIRS Criteria",
                inputs: [
                    {id: "tempSIRS", label:"Temperature (°C)", type:"number", placeholder:"<36 or >38"},
                    {id: "hrSIRS", label:"Heart Rate (bpm)", type:"number", placeholder:">90"},
                    {id: "rrSIRS", label:"Respiratory Rate (breaths/min)", type:"number", placeholder:">20"},
                    {id: "paco2SIRS", label:"PaCO₂ (mmHg)", type:"number", placeholder:"<32 (alternative to RR)"},
                    {id: "wbcSIRS", label:"WBC (cells/mm³)", type:"number", placeholder:"<4000 or >12000"},
                    {id: "bandsSIRS", label:"Immature Bands (%)", type:"number", placeholder:">10% (alternative to WBC)"},
                ], outputs:[{id:"sirsCount", label:"SIRS Criteria Met"}, {id:"sirsDiagnosis", label:"SIRS Diagnosis"}], formulaText:"Two or more of: Temp (<36/>38), HR(>90), RR(>20) or PaCO2(<32), WBC(<4k/>12k) or Bands(>10%).",
                calculate: function(v){ let c=0; const t=parseFloat(v.tempSIRS); if(!isNaN(t)&&(t<36||t>38))c++; if(!isNaN(parseInt(v.hrSIRS))&&parseInt(v.hrSIRS)>90)c++; if((!isNaN(parseInt(v.rrSIRS))&&parseInt(v.rrSIRS)>20)||(!isNaN(parseFloat(v.paco2SIRS))&&parseFloat(v.paco2SIRS)<32))c++; if((!isNaN(parseFloat(v.wbcSIRS))&&(parseFloat(v.wbcSIRS)<4||parseFloat(v.wbcSIRS)>12))||(!isNaN(parseFloat(v.bandsSIRS))&&parseFloat(v.bandsSIRS)>10))c++; return{sirsCount:c, sirsDiagnosis:c>=2?"SIRS Likely Present":"SIRS Not Met"}; },
                getCalculationBreakdown: function(v,r){ return `Criteria met: ${r.sirsCount}. Diagnosis: <strong class="results-strong-text-color">${r.sirsDiagnosis}</strong>`;},
                interpretResult:function(r){ return "SIRS indicates systemic inflammation. If due to infection, it's sepsis. Consider qSOFA/SOFA for sepsis assessment.";}},
            {id: "sofaScoreCalc", name: "SOFA Score", inputs: [{id:"sofaParam1", label:"Sample SOFA Parameter", type:"text"}], outputs:[{id:"sofaInfo", label:"SOFA Score Information"}], infoMessage:"SOFA score assesses organ dysfunction in ICU. Use a dedicated validated tool.", formulaText:"Score based on Respiration, Coagulation, Liver, CV, CNS, Renal function.", calculate: function(v){return {info:"Refer to specialized tool for SOFA."}}, getCalculationBreakdown: function(v,r){return "Requires PaO2/FiO2, Platelets, Bilirubin, MAP/vasopressors, GCS, Creatinine/Urine Output.";}}
        ]
    },
    {
        category: "Neurology", categoryIcon: "🧠",
        calculators: [
            {id: "abcd2Score", name: "ABCD² Score for TIA",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 7,
                    ranges: [
                        { till: 3, label: 'Low Risk', color: '#22c55e' },
                        { till: 5, label: 'Moderate Risk', color: '#f59e0b' },
                        { till: 7, label: 'High Risk', color: '#ef4444' }
                    ]
                },
                inputs: [
                    {id: "ageABCD2", label:"Age ≥ 60 years", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "bpABCD2", label:"BP (SBP≥140 or DBP≥90)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "clinicalFeaturesABCD2", label:"Clinical Features", type:"select", options:[{value:"0", text:"Other (0)"},{value:"1", text:"Speech disturbance w/o weakness (1)"},{value:"2", text:"Unilateral weakness (2)"}]},
                    {id: "durationABCD2", label:"Duration of Symptoms", type:"select", options:[{value:"0", text:"<10 min (0)"},{value:"1", text:"10-59 min (1)"},{value:"2", text:"≥60 min (2)"}]},
                    {id: "diabetesABCD2", label:"Diabetes", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                ], outputs:[{id:"abcd2Total", label:"ABCD² Score", unit: "/ 7"}], formulaText:"A(1) B(1) C(1/2) D(1/2) D(1). Sum points.",
                calculate: function(v){const s=parseInt(v.ageABCD2||0)+parseInt(v.bpABCD2||0)+parseInt(v.clinicalFeaturesABCD2||0)+parseInt(v.durationABCD2||0)+parseInt(v.diabetesABCD2||0); return {abcd2Total:s};},
                getCalculationBreakdown: function(v,r){return `Age: ${v.ageABCD2||0}, BP: ${v.bpABCD2||0}, Clinical: ${v.clinicalFeaturesABCD2||0}, Duration: ${v.durationABCD2||0}, Diabetes: ${v.diabetesABCD2||0}.<br>Total = <strong class="results-strong-text-color">${r.abcd2Total}</strong>`;},
                interpretResult:function(r){ const s = r.abcd2Total; if(s<=3) return "Low risk (0-3)."; if(s<=5) return "Moderate risk (4-5). Hospital observation may be justified."; return "High risk (6-7). Hospital admission strongly considered.";}},
            {id: "gcsNeuro", name: "Glasgow Coma Scale (GCS)",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 15,
                    ranges: [
                        { till: 8, label: 'Severe Injury', color: '#ef4444' },
                        { till: 12, label: 'Moderate Injury', color: '#f59e0b' },
                        { till: 15, label: 'Mild Injury', color: '#22c55e' }
                    ]
                },
                inputs: [
                    { id: "eyeOpeningNeuroGCS", label: "Eye Opening Response", type: "select", options: [ {value: "4", text: "Spontaneous (4)"}, {value: "3", text: "To Speech (3)"}, {value: "2", text: "To Pain (2)"}, {value: "1", text: "No Response (1)"} ] },
                    { id: "verbalResponseNeuroGCS", label: "Verbal Response", type: "select", options: [ {value: "5", text: "Oriented (5)"}, {value: "4", text: "Confused (4)"}, {value: "3", text: "Inappropriate Words (3)"}, {value: "2", text: "Incomprehensible Sounds (2)"}, {value: "1", text: "No Response (1)"} ] },
                    { id: "motorResponseNeuroGCS", label: "Motor Response", type: "select", options: [ {value: "6", text: "Obeys Commands (6)"}, {value: "5", text: "Localizes Pain (5)"}, {value: "4", text: "Withdraws from Pain (4)"}, {value: "3", text: "Abnormal Flexion (Decorticate) (3)"}, {value: "2", text: "Abnormal Extension (Decerebrate) (2)"}, {value: "1", text: "No Response (Flaccid) (1)"} ] }
                ], outputs:[{id:"totalGcsNeuro", label:"Total GCS Score", unit: "/ 15"}], formulaText:"Sum of E, V, M scores.",
                calculate: function(v){const s=parseInt(v.eyeOpeningNeuroGCS||0)+parseInt(v.verbalResponseNeuroGCS||0)+parseInt(v.motorResponseNeuroGCS||0); return {totalGcsNeuro:s};},
                getCalculationBreakdown: function(v,r){ return `Eye: ${v.eyeOpeningNeuroGCS||0}, Verbal: ${v.verbalResponseNeuroGCS||0}, Motor: ${v.motorResponseNeuroGCS||0}.<br>Total = <strong class="results-strong-text-color">${r.totalGcsNeuro}</strong>`;},
                interpretResult:function(r){const score = parseInt(r.totalGcsNeuro); if (score <= 8) return "Severe Head Injury."; if (score <= 12) return "Moderate Head Injury."; return "Mild Head Injury.";}},
            {id: "nihssScore", name: "NIH Stroke Scale (NIHSS)", inputs: [{id:"nihssParam1", label:"Sample NIHSS Item", type:"text"}], outputs:[{id:"nihssInfo", label:"NIHSS Information"}], infoMessage:"NIHSS is a detailed neurologic exam for stroke. Requires certified training and a specific tool/form.", formulaText:"15-item neurologic exam; score 0-42.", calculate: function(v){return {info:"Refer to certified training/tool for NIHSS."}}, getCalculationBreakdown: function(v,r){return "Assesses LOC, Gaze, Visual, Facial Palsy, Motor Arm/Leg, Ataxia, Sensory, Language, Dysarthria, Extinction/Inattention.";}}
        ]
    },
    {
        category: "Nephrology & General Medicine", categoryIcon: "🧪",
        calculators: [
            {id: "anionGapNephrology", name: "Anion Gap",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: 'mEq/L',
                    maxScore: 25,
                    ranges: [
                        { till: 2, label: 'Low', color: '#f59e0b' },
                        { till: 12, label: 'Normal', color: '#22c55e' },
                        { till: 25, label: 'High', color: '#ef4444' }
                    ]
                },
                inputs: [
                    { id: "sodiumNephroAG", label: "Sodium (Na⁺)", type: "number", unit: "mEq/L", placeholder: "e.g., 140" },
                    { id: "chlorideNephroAG", label: "Chloride (Cl⁻)", type: "number", unit: "mEq/L", placeholder: "e.g., 100" },
                    { id: "bicarbonateNephroAG", label: "Bicarbonate (HCO₃⁻)", type: "number", unit: "mEq/L", placeholder: "e.g., 22" }
                ], outputs:[{id:"anionGapValueNephro", label:"Anion Gap", unit: "mEq/L"}], formulaText:"[Na⁺] - ([Cl⁻] + [HCO₃⁻])",
                calculate: function(v){const na=parseFloat(v.sodiumNephroAG),cl=parseFloat(v.chlorideNephroAG),hco3=parseFloat(v.bicarbonateNephroAG); if(isNaN(na)||isNaN(cl)||isNaN(hco3))return{error:"Invalid numerics"}; return {anionGapValueNephro:(na-(cl+hco3)).toFixed(0)};},
                getCalculationBreakdown: function(v,r){ return `Na: ${v.sodiumNephroAG}, Cl: ${v.chlorideNephroAG}, HCO3: ${v.bicarbonateNephroAG}.<br>${v.sodiumNephroAG} - (${v.chlorideNephroAG} + ${v.bicarbonateNephroAG}) = <strong class="results-strong-text-color">${r.anionGapValueNephro} mEq/L</strong>`;},
                interpretResult:function(r){ const gap = parseFloat(r.anionGapValueNephro); if (gap > 12) return "High Anion Gap. Normal: 3-11 mEq/L."; if (gap < 3) return "Low Anion Gap. Normal: 3-11 mEq/L."; return "Normal Anion Gap.";}},
            {id: "creatinineClearanceNephrology", name: "Creatinine Clearance (Cockcroft-Gault)",
                inputs: [
                    { id: "ageYearsNephro", label: "Age", type: "number", unit: "years", placeholder: "e.g., 65" },
                    { id: "weightCrClNephro", label: "Weight (Mass)", type: "number", unit: "kg", placeholder: "e.g., 70" },
                    { id: "serumCreatinineNephro", label: "Serum Creatinine", type: "number", unit: "mg/dL", placeholder: "e.g., 1.2" },
                    { id: "genderNephro", label: "Gender", type: "select", options: [ {value: "male", text: "Male"}, {value: "female", text: "Female"} ] }
                ], outputs:[{id:"crclValueNephro", label:"Creatinine Clearance", unit: "mL/min"}], formulaText:"((140 - Age) * Mass) / (72 * Cr) (x0.85 if female)",
                calculate: function(v){ const age=parseInt(v.ageYearsNephro),w=parseFloat(v.weightCrClNephro),cr=parseFloat(v.serumCreatinineNephro); if(isNaN(age)||isNaN(w)||isNaN(cr)||cr===0||age<=0||w<=0||cr<=0) return{error:"Invalid inputs"}; let crcl=((140-age)*w)/(72*cr); if(v.genderNephro==="female")crcl*=0.85; return {crclValueNephro:crcl.toFixed(1)};},
                getCalculationBreakdown: function(v,r){ return `Age: ${v.ageYearsNephro}, Wt: ${v.weightCrClNephro}, SCr: ${v.serumCreatinineNephro}, Gender: ${v.genderNephro}. Formula: <strong class="results-strong-text-color">${r.crclValueNephro} mL/min</strong>`;},
                interpretResult:function(r){ const crcl = parseFloat(r.crclValueNephro); if (crcl < 15) return "Stage 5 CKD."; else if (crcl < 30) return "Stage 4 CKD."; else if (crcl < 60) return "Stage 3 CKD."; else if (crcl < 90) return "Stage 2 CKD (if other kidney damage signs)."; return "Normal or Stage 1 CKD (if other signs).";}}
        ]
    },
    {
        category: "Gastroenterology & Hepatology", categoryIcon: "🤢",
        calculators: [
            {id: "childPughScore", name: "Child-Pugh Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 15,
                    ranges: [
                        { till: 6, label: 'Class A', color: '#22c55e' },
                        { till: 9, label: 'Class B', color: '#f59e0b' },
                        { till: 15, label: 'Class C', color: '#ef4444' }
                    ]
                },
                inputs: [
                    {id: "bilirubinChild", label:"Total Bilirubin (mg/dL)", type:"select", options:[{value:"1",text:"<2 (1)"},{value:"2",text:"2-3 (2)"},{value:"3",text:">3 (3)"}]},
                    {id: "albuminChild", label:"Serum Albumin (g/dL)", type:"select", options:[{value:"1",text:">3.5 (1)"},{value:"2",text:"2.8-3.5 (2)"},{value:"3",text:"<2.8 (3)"}]},
                    {id: "inrChild", label:"INR", type:"select", options:[{value:"1",text:"<1.7 (1)"},{value:"2",text:"1.7-2.3 (2)"},{value:"3",text:">2.3 (3)"}]},
                    {id: "ascitesChild", label:"Ascites", type:"select", options:[{value:"1",text:"None (1)"},{value:"2",text:"Mild (Slight) (2)"},{value:"3",text:"Moderate to Severe (Tense) (3)"}]},
                    {id: "encephalopathyChild", label:"Hepatic Encephalopathy", type:"select", options:[{value:"1",text:"None (1)"},{value:"2",text:"Grade 1-2 (Mild) (2)"},{value:"3",text:"Grade 3-4 (Severe) (3)"}]},
                ], outputs:[{id:"childPughTotal", label:"Child-Pugh Score", unit: "/ 15"}, {id:"childPughClass", label:"Child-Pugh Class"}], formulaText:"Sum of points for Bili, Alb, INR, Ascites, Enceph.",
                calculate: function(v){const s = parseInt(v.bilirubinChild||0)+parseInt(v.albuminChild||0)+parseInt(v.inrChild||0)+parseInt(v.ascitesChild||0)+parseInt(v.encephalopathyChild||0); let c=""; if(s<=6)c="Class A"; else if(s<=9)c="Class B"; else c="Class C"; return {childPughTotal:s, childPughClass:c};},
                getCalculationBreakdown: function(v,r){return `Bili: ${v.bilirubinChild||0}, Alb: ${v.albuminChild||0}, INR: ${v.inrChild||0}, Ascites: ${v.ascitesChild||0}, Enceph: ${v.encephalopathyChild||0}.<br>Total = <strong class="results-strong-text-color">${r.childPughTotal} (${r.childPughClass})</strong>`;},
                interpretResult:function(r){return `Score: ${r.childPughTotal}, Class: ${r.childPughClass}. Class A (5-6): Least severe. Class B (7-9): Moderately severe. Class C (10-15): Most severe.`;}},
            {id: "meldScore", name: "MELD Score",
                inputs: [
                    {id: "creatinineMELD", label:"Serum Creatinine", type:"number", unit:"mg/dL"},
                    {id: "bilirubinMELD", label:"Total Bilirubin", type:"number", unit:"mg/dL"},
                    {id: "inrMELD", label:"INR", type:"number"},
                    {id: "sodiumMELD", label:"Serum Sodium (optional for MELD-Na context)", type:"number", unit:"mEq/L", placeholder:"Optional"},
                    {id: "onDialysisMELD", label:"On Dialysis (at least twice in last week)?", type:"select", options:[{value:"no", text:"No"},{value:"yes", text:"Yes"}]}
                ], outputs:[{id:"meldScoreValue", label:"MELD Score"}], infoMessage:"MELD score calculation is complex. This provides an estimate. MELD-Na may also be used.", formulaText:"Logarithmic formula based on Cr, Bili, INR. See specific guidelines.",
                calculate: function(v){ let cr=parseFloat(v.creatinineMELD),bili=parseFloat(v.bilirubinMELD),inr=parseFloat(v.inrMELD); if(isNaN(cr)||isNaN(bili)||isNaN(inr))return{error:"Creatinine, Bilirubin, and INR are required."}; if(v.onDialysisMELD==="yes" || cr > 4.0) cr=4.0; else if(cr < 1.0 && (v.creatinineMELD && v.creatinineMELD !== '')) cr = Math.max(cr, 0.8); else if(cr<1.0) cr=1.0; /* Default if not provided or to avoid log issues */ if(bili<1.0)bili=1.0; if(inr<1.0)inr=1.0; let meld=Math.round((0.957*Math.log(cr)+0.378*Math.log(bili)+1.120*Math.log(inr)+0.643)*10); if(meld<6)meld=6; if(meld>40)meld=40; return {meldScoreValue:meld};},
                getCalculationBreakdown: function(v,r){ return `Cr: ${v.creatinineMELD}, Bili: ${v.bilirubinMELD}, INR: ${v.inrMELD}, Dialysis: ${v.onDialysisMELD}.<br>Calculated MELD Score: <strong class="results-strong-text-color">${r.meldScoreValue}</strong>. (Sodium ${v.sodiumMELD || 'N/A'})`;},
                interpretResult:function(r){ return `MELD Score: ${r.meldScoreValue}. Higher score indicates more severe liver disease and higher transplant priority. Ranges 6-40.`;}}
        ]
    },
    {
        category: "Perioperative Medicine", categoryIcon: "🔪",
        calculators: [
            {id: "hasBledScore", name: "HAS-BLED Score",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 9,
                    ranges: [
                        { till: 2, label: 'Low-Mod. Risk', color: '#22c55e' },
                        { till: 9, label: 'High Risk', color: '#ef4444' }
                    ]
                },
                inputs: [
                    {id: "hypertensionHASBLED", label:"Hypertension (uncontrolled SBP >160)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "abnormalRenalHASBLED", label:"Abnormal Renal Function (dialysis, transplant, Cr>2.26)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "abnormalLiverHASBLED", label:"Abnormal Liver Function (cirrhosis, Bili>2xULN, AST/ALT/ALP>3xULN)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "strokeHASBLED", label:"Stroke History", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "bleedingHistoryHASBLED", label:"Bleeding History or Predisposition", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "labileINRSHASBLED", label:"Labile INRs (TTR <60%)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "elderlyHASBLED", label:"Elderly (Age > 65 years)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "drugsHASBLED", label:"Drugs (Antiplatelets, NSAIDs)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "alcoholHASBLED", label:"Alcohol (≥8 drinks/week)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                ], outputs:[{id:"hasBledTotal", label:"HAS-BLED Score", unit: "/ 9"}], formulaText:"H(1) A(1or2) S(1) B(1) L(1) E(1) D(1or2). Sum points.",
                calculate: function(v){const s=parseInt(v.hypertensionHASBLED||0)+parseInt(v.abnormalRenalHASBLED||0)+parseInt(v.abnormalLiverHASBLED||0)+parseInt(v.strokeHASBLED||0)+parseInt(v.bleedingHistoryHASBLED||0)+parseInt(v.labileINRSHASBLED||0)+parseInt(v.elderlyHASBLED||0)+parseInt(v.drugsHASBLED||0)+parseInt(v.alcoholHASBLED||0); return{hasBledTotal:s};},
                getCalculationBreakdown: function(v,r){return `HTN: ${v.hypertensionHASBLED||0}, Renal: ${v.abnormalRenalHASBLED||0}, Liver: ${v.abnormalLiverHASBLED||0}, Stroke: ${v.strokeHASBLED||0}, Bleed Hist: ${v.bleedingHistoryHASBLED||0}, INR: ${v.labileINRSHASBLED||0}, Age>65: ${v.elderlyHASBLED||0}, Drugs: ${v.drugsHASBLED||0}, Alcohol: ${v.alcoholHASBLED||0}.<br>Total = <strong class="results-strong-text-color">${r.hasBledTotal}</strong>`;},
                interpretResult:function(r){ const s = r.hasBledTotal; if(s>=3) return "High risk of bleeding (Score ≥3). Careful monitoring and risk factor modification needed if on anticoagulants."; return "Low-moderate risk of bleeding (Score 0-2).";}},
            {id: "leeScore", name: "Revised Cardiac Risk Index (RCRI / Lee Score)",
                visualizationType: "donutChart",
                visualizationParams: {
                    unit: '',
                    maxScore: 6,
                    ranges: [
                        { till: 0, label: 'Class I (~0.4% risk)', color: '#22c55e' },
                        { till: 1, label: 'Class II (~0.9% risk)', color: '#f59e0b' },
                        { till: 2, label: 'Class III (~6.6% risk)', color: '#ef4444' },
                        { till: 6, label: 'Class IV (~11% risk)', color: '#a855f7' }
                    ]
                },
                inputs: [
                    {id: "highRiskSurgeryLee", label:"High-Risk Surgery (intraperitoneal, intrathoracic, suprainguinal vascular)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "ihdLee", label:"History of Ischemic Heart Disease (MI, +stress test, angina, nitrates)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "chfLee", label:"History of Congestive Heart Failure", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "cvdLee", label:"History of Cerebrovascular Disease (Stroke/TIA)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "insulinLee", label:"Preoperative Insulin Treatment for Diabetes", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                    {id: "creatinineLee", label:"Preoperative Serum Creatinine >2.0 mg/dL (>177 µmol/L)", type:"select", options:[{value:"0", text:"No (0)"},{value:"1", text:"Yes (1)"}]},
                ], outputs:[{id:"leeTotal", label:"RCRI Score", unit: "/ 6"}, {id:"leeRiskClass", label:"Risk Class"}], formulaText:"Sum of 6 independent risk factors.",
                calculate: function(v){const s=parseInt(v.highRiskSurgeryLee||0)+parseInt(v.ihdLee||0)+parseInt(v.chfLee||0)+parseInt(v.cvdLee||0)+parseInt(v.insulinLee||0)+parseInt(v.creatinineLee||0); let rc=""; if(s===0)rc="Class I (Risk ~0.4%)"; else if(s===1)rc="Class II (Risk ~0.9%)"; else if(s===2)rc="Class III (Risk ~6.6%)"; else rc="Class IV (Risk ~11%)"; return{leeTotal:s, leeRiskClass:rc};},
                getCalculationBreakdown: function(v,r){return `High-Risk Surg: ${v.highRiskSurgeryLee||0}, IHD: ${v.ihdLee||0}, CHF: ${v.chfLee||0}, CVD: ${v.cvdLee||0}, Insulin: ${v.insulinLee||0}, Cr>2: ${v.creatinineLee||0}.<br>Total = <strong class="results-strong-text-color">${r.leeTotal} (${r.leeRiskClass})</strong>`;},
                interpretResult:function(r){return `Score: ${r.leeTotal}, ${r.leeRiskClass}. Guides preoperative cardiac assessment.`;}}
        ]
    }
];

// --- EXPLORE TAB Data ---
const nursingWorldContent: ExploreSection[] = [
    {
        section: "SNA Prep Hub: Conquer Your Exams",
        icon: "🏆", // Trophy for competitive success
        description: "Your dedicated launchpad for competitive nursing exams. Achieve your dreams with SNA.",
        items: [
            {
                id: "nclex-rn",
                name: "NCLEX-RN",
                brief: "Essential for practicing abroad.",
                motivationalTag: "AIM NCLEX! Your SNA Success Story Starts Here.",
                type: "exam",
                resources: [
                    { type: "Book", title: "Saunders Comprehensive Review for the NCLEX-RN", author: "Silvestri" },
                    { type: "Book", title: "Kaplan NCLEX-RN Premier", author: "Kaplan" },
                    { type: "Online Course", title: "UWorld NCLEX-RN QBank", author: "UWorld" }
                ],
                link: "#"
            },
            {
                id: "aiims-norcet",
                name: "AIIMS NORCET",
                brief: "Your gateway to prestigious central government nursing roles in India.",
                motivationalTag: "Conquer AIIMS! SNA Paves Your Path to Excellence.",
                type: "exam",
                resources: [
                    { type: "Book", title: "Dass & Roy's Staff Nurse Recruitment Exam Guide", author: "Dass & Roy" },
                    { type: "Book", title: "Target High", author: "M.S.N. Reddy" },
                    { type: "Online Platform", title: "PrepLadder/Marrow Nursing", author: "Various" }
                ],
                link: "#"
            },
            {
                id: "jipmer-sn",
                name: "JIPMER Staff Nurse",
                brief: "Elevate your career at a top-tier medical institute.",
                motivationalTag: "JIPMER Ready? SNA Helps You Ace It!",
                type: "exam",
                resources: [
                    { type: "Book", title: "JIPMER Staff Nurse Exam Guide", author: "Various Publishers" },
                    { type: "Study Material", title: "Previous Year Question Papers", author: "JIPMER" }
                ],
                link: "#"
            },
            {
                id: "prometric-exams",
                name: "Prometric Exams (Gulf Countries)",
                brief: "Unlock international career opportunities.",
                motivationalTag: "Prometric Bound? Your Global Journey with SNA.",
                type: "exam",
                resources: [
                    { type: "Book", title: "Prometric Exam for Nurses: Q&A", author: "Various Publishers" },
                    { type: "Online Platform", title: "Online Q-Banks (specific to country)", author: "Various" }
                ],
                link: "#"
            },
            {
                id: "pgimer-sn",
                name: "PGIMER Staff Nurse",
                brief: "Join the ranks of leading healthcare professionals.",
                type: "exam",
                resources: [],
                link: "#"
            },
            {
                id: "rrb-sn",
                name: "RRB Staff Nurse",
                brief: "A stable and rewarding career in railway healthcare.",
                type: "exam",
                resources: [],
                link: "#"
            },
            {
                id: "dsssb-sn",
                name: "DSSSB Staff Nurse",
                brief: "Opportunities in the heart of the capital.",
                type: "exam",
                resources: [],
                link: "#"
            },
            {
                id: "state-psc-sn",
                name: "State PSC Staff Nurse",
                brief: "Fulfill your purpose serving your home state.",
                type: "exam",
                resources: [],
                link: "#"
            }
        ]
    },
    {
        section: "SNA Study Essentials: Resources & Insights",
        icon: "📚",
        description: "Curated books and practice papers to boost your preparation.",
        items: [
            { id: "nclex-saunders", name: "NCLEX Saunders Comprehensive Review", brief: "The Gold Standard. Essential for NCLEX prep.", type: "book", resources: [{type: "Book", title: "Saunders Comprehensive Review", author: "Silvestri"}], link: "#" },
            { id: "nclex-kaplan", name: "NCLEX Kaplan Premier", brief: "Strategic Test Taking. Kaplan's proven methods.", type: "book", resources: [{type: "Book", title: "Kaplan NCLEX-RN Premier", author: "Kaplan"}], link: "#" },
            { id: "norcet-target-high", name: "NORCET Target High", brief: "Aim for Top Ranks. Comprehensive for AIIMS & more.", type: "book", resources: [{type: "Book", title: "Target High", author: "M.S.N. Reddy"}], link: "#" },
            { id: "norcet-mission-parichika", name: "NORCET Mission Parichika", brief: "Unlock Your Potential. A complete guide for NORCET.", type: "book", resources: [{type: "Book", title: "Mission Parichika", author: "Various"}], link: "#" },
        ]
    },
    {
        section: "SNA Sound Waves: Nursing Podcasts",
        icon: "🎧",
        description: "Listen, learn, and grow! Insights and interviews from the world of nursing, in your language.",
        items: [
            { id: "podcast-en-1", name: "The SNA Clinical Corner: IV Fluid Rates Explained", brief: "Quick concepts for daily practice.", type: "podcast", lang: "en", url: "https://example.com/podcast_iv_rates.mp3" },
            { id: "podcast-en-2", name: "NCLEX Strategies: Demystifying Pharmacology", brief: "Tips from top educators.", type: "podcast", lang: "en", url: "https://example.com/podcast_pharmacology.mp3" },
            { id: "podcast-hi-1", name: "AIIMS NORCET: सफल होने के नुस्खे (Tips for Success)", brief: "टॉपर्स से सीखें और AIIMS में जगह बनाएं।", type: "podcast", lang: "hi", url: "https://example.com/podcast_aiims_hindi.mp3" },
            { id: "podcast-hi-2", name: "नर्सिंग फंडामेंटल्स: आवश्यक कौशल (Essential Skills)", brief: "हर छात्र नर्स के लिए बुनियादी ज्ञान।", type: "podcast", lang: "hi", url: "https://example.com/podcast_nursing_hindi.mp3" },
            { id: "podcast-ml-1", name: "IV ഫ്ലൂയിഡ് നിരക്കുകൾ: എളുപ്പത്തിൽ പഠിക്കാം (IV Fluid Rates: Learn Easily)", brief: "ക്ലിനിക്കൽ പരിശീലനത്തിന് ആവശ്യമായ അറിവ്.", type: "podcast", lang: "ml", url: "https://example.com/podcast_iv_malayalam.mp3" },
            { id: "podcast-ml-2", name: "ഫാർമക്കോളജി അവലോകനം (Pharmacology Review)", brief: "മരുന്നുകളെക്കുറിച്ച് ആഴത്തിലുള്ള പഠനം.", type: "podcast", lang: "ml", url: "https://example.com/podcast_pharmacology_malayalam.mp3" },
            { id: "podcast-ta-1", name: "செவிலியர் கணக்கீடுகள்: சுலபமாக கற்றுக்கொள்ளுங்கள் (Nursing Calculations: Learn Easily)", brief: "மருத்துவ அளவீடுகளை சரியாக கணக்கிட உதவும்.", type: "podcast", lang: "ta", url: "https://example.com/podcast_calc_tamil.mp3" },
            { id: "podcast-ta-2", name: "NCLEX தேர்வுக்கான உத்திகள் (NCLEX Exam Strategies)", brief: "தேர்வில் வெற்றிபெற சிறந்த வழிகாட்டுதல்கள்.", type: "podcast", lang: "ta", url: "https://example.com/podcast_nclex_tamil.mp3" }
        ]
    },
    {
        section: "SNA Compass: Navigate Your Career",
        icon: "🧭",
        description: "Find your true north in nursing. Discover diverse career paths and connect with your community through SNA.",
        items: [
            { id: "nurse-spotlight", name: "Nurse Success Stories", brief: "Inspiring journeys of fellow nurses.", type: "career", link: "#" },
            { id: "career-paths", name: "Diverse Nursing Career Paths", brief: "Explore specializations and future roles.", type: "career", link: "#" },
            { id: "pro-orgs", name: "Professional Nursing Organizations", brief: "Connect, learn, and grow your network.", type: "career", link: "#" },
            { id: "interview-tips", name: "Your First Job: Interview & Resume Tips", brief: "Ace your interviews and land your dream role.", type: "career", link: "#" }
        ]
    }
];

const aiimsPreviousPapers = [
    { year: 2024, set: "Set A", file: "aiims_norcet_2024_A.pdf" },
    { year: 2024, set: "Set B", file: "aiims_norcet_2024_B.pdf" },
    { year: 2023, set: "Set A", file: "aiims_norcet_2023_A.pdf" },
    { year: 2023, set: "Set B", file: "aiims_norcet_2023_B.pdf" },
    { year: 2022, set: "Set A", file: "aiims_norcet_2022_A.pdf" }
];

// --- LAB VALUES DATA (from PDF) ---
const allLabValuesData: LabCategory[] = [
    {
        title: "Serum, Plasma, and Whole Blood Chemistries",
        icon: "🩸",
        tableId: "table-c1",
        values: [
            { test: "Aldolase", conventionalUnits: "22-59 mU/L", siUnits: "22-59 mU/L", etiology: { high: "Skeletal muscle disease", low: "Muscle-wasting disease" } },
            { test: "α₁-Antitrypsin", conventionalUnits: "85-213 mg/dL", siUnits: "0.85-2.13 g/L", etiology: { high: "Acute and chronic inflammation, arthritis", low: "Early-onset emphysema, malnutrition, nephrotic syndrome" } },
            { test: "α-Fetoprotein", conventionalUnits: "<40 ng/mL", siUnits: "<40 mcg/L", etiology: { high: "Cancer of testes, ovaries, and liver", low: "" } },
            { test: "Ammonia", conventionalUnits: "10-80 mcg/dL", siUnits: "6-47 µmol/L", etiology: { high: "Severe liver disease", low: "Acute alcoholism, cirrhosis of liver, extensive destruction of pancreas" } },
            { test: "Amylase", conventionalUnits: "60-120 Somogyi U/dL", siUnits: "30-220 U/L", etiology: { high: "Acute and chronic pancreatitis, salivary gland disease, perforated ulcers", low: "Acute alcoholism, cirrhosis of liver, extensive destruction of pancreas" } },
            { test: "Bicarbonate", conventionalUnits: "21-28 mEq/L", siUnits: "21-28 mmol/L", etiology: { high: "Compensated respiratory acidosis, metabolic alkalosis", low: "Compensated respiratory alkalosis, metabolic acidosis" } },
            { test: "b-Type natriuretic peptide (BNP)", conventionalUnits: "<100 pg/mL", siUnits: "<100 pmol/L", etiology: { high: "Heart failure", low: "" } },
            { test: "Bilirubin, Total", conventionalUnits: "0.3-1.0 mg/dL", siUnits: "5.1-17 µmol/L", etiology: { high: "Biliary obstruction, hemolytic anemia, impaired liver function, pernicious anemia", low: "" } },
            { test: "Bilirubin, Indirect", conventionalUnits: "0.2-0.8 mg/dL", siUnits: "3.4-12.0 µmol/L", etiology: { high: "Biliary obstruction, hemolytic anemia, impaired liver function, pernicious anemia", low: "" } },
            { test: "Bilirubin, Direct", conventionalUnits: "0.1-0.3 mg/dL", siUnits: "1.7-5.1 µmol/L", etiology: { high: "Biliary obstruction, hemolytic anemia, impaired liver function, pernicious anemia", low: "" } },
            { test: "Blood gases, Arterial pH", conventionalUnits: "7.35-7.45", siUnits: "7.35-7.45", etiology: { high: "Alkalosis", low: "Acidosis" }, notes: "Because arterial blood gases are influenced by altitude, the value for PaO₂ decreases as altitude increases. The lower value is normal for an altitude of 1 mile." },
            { test: "Blood gases, Venous pH", conventionalUnits: "7.31-7.41", siUnits: "7.31-7.41", etiology: { high: "Alkalosis", low: "Acidosis" } },
            { test: "Blood gases, PaCO₂", conventionalUnits: "35-45 mm Hg", siUnits: "4.66-5.98 kPa", etiology: { high: "Compensated metabolic alkalosis, Respiratory acidosis", low: "Compensated metabolic acidosis, Respiratory alkalosis" } },
            { test: "Blood gases, PvCO₂", conventionalUnits: "40-50 mm Hg", siUnits: "5.06-7.32 kPa", etiology: { high: "Compensated metabolic alkalosis, Respiratory acidosis", low: "Compensated metabolic acidosis, Respiratory alkalosis" } },
            { test: "Blood gases, PaO₂", conventionalUnits: "80-100 mm Hg", siUnits: "10.6-13.33 kPa", etiology: { high: "Administration of high concentration of O₂", low: "Chronic lung disease, decreased cardiac output" } },
            { test: "Blood gases, PvO₂", conventionalUnits: "40-50 mm Hg", siUnits: "5.04-5.57 kPa", etiology: { high: "Administration of high concentration of O₂", low: "Chronic lung disease, decreased cardiac output" } },
            { test: "Calcium (total)", conventionalUnits: "9.0-10.5 mg/dL", siUnits: "2.25-2.62 mmol/L", etiology: { high: "Hyperthyroidism, hyperparathyroidism, vitamin D intoxication, multiple myeloma", low: "Pancreatitis, hypoparathyroidism, malabsorption syndrome, renal failure, vitamin D deficiency" } },
            { test: "Calcium (ionized)", conventionalUnits: "4.5-5.6 mg/dL", siUnits: "1.05-1.3 mmol/L", etiology: { high: "Acidosis", low: "Alkalosis" } },
            { test: "Chloride", conventionalUnits: "98-106 mEq/L", siUnits: "98-106 mmol/L", etiology: { high: "Metabolic acidosis, respiratory alkalosis, corticosteroid therapy, uremia", low: "Addison's disease, vomiting, metabolic alkalosis, respiratory acidosis" } },
            { test: "Cholesterol", conventionalUnits: "<200 mg/dL", siUnits: "<5.2 mmol/L", etiology: { high: "Biliary obstruction, hypothyroidism, idiopathic hypercholesterolemia, renal disease, uncontrolled diabetes", low: "Extensive liver disease, hyperthyroidism, malnutrition, malabsorption" } },
            { test: "High-density lipoproteins (HDLs)", conventionalUnits: "Male: >45 mg/dL, Female: >55 mg/dL", siUnits: "Male: >0.75 mmol/L, Female: >0.91 mmol/L", etiology: { high: "Excessive exercise", low: "Metabolic syndrome, liver disease" } },
            { test: "Low-density lipoproteins (LDLs)", conventionalUnits: "Recommended: <130 mg/dL", siUnits: "", etiology: { high: "Chronic liver disease, familial hypercholesterolemia, nephrotic syndrome", low: "Hyperthyroidism" } },
            { test: "Very low-density lipoproteins (VLDLs)", conventionalUnits: "7-32 mg/dL", siUnits: "", etiology: { high: "Familial hypercholesterolemia, nephrotic syndrome", low: "Hyperthyroidism" } },
            { test: "Cortisol", conventionalUnits: "8 AM: 5-23 mcg/dL, 4 PM: 3-13 mcg/dL", siUnits: "8 AM: 138-635 nmol/L, 4 PM: 83-359 nmol/L", etiology: { high: "Cushing syndrome, hyperthyroidism", low: "Adrenal insufficiency, panhypopituitary states" } },
            { test: "Creatine kinase (CK)", conventionalUnits: "Male: 55-170 U/L, Female: 30-135 U/L", siUnits: "Male: 55-170 U/L, Female: 30-135 U/L", etiology: { high: "Musculoskeletal injury or disease, myocardial infarction, severe myocarditis, exercise, numerous IM injections", low: "" } },
            { test: "CK-MB", conventionalUnits: "<4%-6% of total CK", siUnits: "<0.4-0.6", etiology: { high: "Acute myocardial infarction", low: "" } },
            { test: "Creatinine", conventionalUnits: "Male: 0.6-1.2 mg/dL, Female: 0.5-1.1 mg/dL", siUnits: "Male: 53-106 µmol/L, Female: 44-97 µmol/L", etiology: { high: "Severe renal disease", low: "Decreased muscle mass, debilitation" } },
            { test: "Ferritin", conventionalUnits: "Male: 12-300 ng/mL, Female: 10-150 ng/mL", siUnits: "Male: 12-300 mcg/L, Female: 10-150 mcg/L", etiology: { high: "Anemia of chronic disease, sideroblastic anemia", low: "Iron-deficiency anemia" } },
            { test: "Folic acid (folate)", conventionalUnits: "5-25 ng/mL", siUnits: "11-57 nmol/L", etiology: { high: "Hypothyroidism, pernicious anemia", low: "Alcoholism, hemolytic anemia, inadequate diet, malabsorption syndrome, megaloblastic anemia" } },
            { test: "γ-Glutamyl transferase (GGT)", conventionalUnits: "Male and Female >45: 8-38 U/L, Female <45: 5-27 U/L", siUnits: "Male and Female >45: 8-38 U/L, Female <45: 5-27 U/L", etiology: { high: "Liver disease, infectious myocardial infarction, pancreatitis, hyperthyroidism", low: "Hypothyroidism" } },
            { test: "Glucose (fasting)", conventionalUnits: "74-106 mg/dL", siUnits: "4.1-5.9 mmol/L", etiology: { high: "Acute stress, Cushing disease, diabetes, hyperthyroidism, pancreatic insufficiency", low: "Addison's disease, hepatic disease, hypothyroidism, insulin overdosage, pancreatic tumor, pituitary hypofunction" } },
            { test: "Haptoglobin", conventionalUnits: "50-220 mg/dL", siUnits: "0.5-2.2 g/L", etiology: { high: "Infectious and inflammatory processes, cancer", low: "Hemolytic anemia, malnutrition, chronic liver disease" } },
            { test: "Insulin (fasting)", conventionalUnits: "6-26 µU/mL", siUnits: "43-186 pmol/L", etiology: { high: "Acromegaly, adenoma of pancreatic islet cells, Cushing syndrome", low: "Diabetes, hypopituitarism" } },
            { test: "Iron, total", conventionalUnits: "Male: 80-180 mcg/dL, Female: 60-160 mcg/dL", siUnits: "Male: 14-32 µmol/L, Female: 11-29 µmol/L", etiology: { high: "Excess RBC destruction, hepatitis, massive blood transfusion", low: "Anemia of chronic disease, iron-deficiency anemia, cancer" } },
            { test: "(Total) iron-binding capacity", conventionalUnits: "250-460 mcg/dL", siUnits: "45-82 µmol/L", etiology: { high: "Iron-deficient state, polycythemia", low: "Cirrhosis, chronic infections, pernicious anemia" } },
            { test: "Lactic acid (L-Lactate), venous", conventionalUnits: "5-20 mg/dL", siUnits: "0.6-2.2 mmol/L", etiology: { high: "Acidosis, liver disease, sepsis, shock", low: "" } },
            { test: "Lactic dehydrogenase (LDH)", conventionalUnits: "100-190 U/L", siUnits: "100-190 U/L", etiology: { high: "Heart failure, hemolytic disorders, hepatitis, metastatic cancer of liver, myocardial infarction, pernicious anemia, pulmonary embolus, skeletal muscle damage", low: "" } },
            { test: "LDH₁, soenzymes", conventionalUnits: "17%-27%", siUnits: "0.17-0.27", etiology: { high: "Myocardial infarction, pernicious anemia", low: "" } },
            { test: "LDH₂, soenzymes", conventionalUnits: "27%-37%", siUnits: "0.27-0.37", etiology: { high: "Pulmonary embolus, sickle cell crisis", low: "" } },
            { test: "LDH₃, soenzymes", conventionalUnits: "18%-25%", siUnits: "0.18-0.26", etiology: { high: "Malignant lymphoma, pulmonary embolus", low: "" } },
            { test: "LDH₄, soenzymes", conventionalUnits: "3%-8%", siUnits: "0.03-0.08", etiology: { high: "Systemic lupus erythematosus, pulmonary infarction", low: "" } },
            { test: "LDH₅, soenzymes", conventionalUnits: "0%-6%", siUnits: "0.00-0.05", etiology: { high: "Heart failure, hepatitis, pulmonary embolus and infarction, skeletal muscle damage", low: "" } },
            { test: "Lipase", conventionalUnits: "0-160 U/L", siUnits: "0-160 U/L", etiology: { high: "Acute pancreatitis, hepatic disorders, perforated peptic ulcer", low: "" } },
            { test: "Magnesium", conventionalUnits: "1.3-2.1 mEq/L", siUnits: "0.65-1.05 mmol/L", etiology: { high: "Addison's disease, hypothyroidism, renal failure", low: "Chronic alcoholism, severe malabsorption" } },
            { test: "Osmolality", conventionalUnits: "285-295 mOsm/kg", siUnits: "285-295 mmol/kg", etiology: { high: "Chronic renal disease, diabetes, diabetes insipidus", low: "Addison's disease, diuretic therapy, SIADH, hypervolemia" } },
            { test: "O₂ saturation (arterial) (SaO₂)", conventionalUnits: ">95%", siUnits: ">0.95", etiology: { high: "Polycythemia", low: "Anemia, cardiac decompensation, respiratory disorders" } },
            { test: "Phosphatase, alkaline", conventionalUnits: "30-120 U/L", siUnits: "0.5-2.0 µkat/L", etiology: { high: "Biliary system obstruction, bone diseases, marked hyperparathyroidism, rickets", low: "Excess vitamin D ingestion, hypothyroidism" } },
            { test: "Phosphorus (phosphate)", conventionalUnits: "3.0-4.5 mg/dL", siUnits: "0.97-1.45 mmol/L", etiology: { high: "Bone cancer, hypoparathyroidism, renal disease, vitamin D intoxication, hypocalcemia", low: "Diabetes, hyperparathyroidism, vitamin D deficiency" } },
            { test: "Potassium", conventionalUnits: "3.5-5.0 mEq/L", siUnits: "3.5-5.0 mmol/L", etiology: { high: "Addison's disease, diabetic ketosis, massive tissue destruction, renal failure, infection, dehydration", low: "Cushing syndrome, diarrhea (severe), diuretic therapy, gastrointestinal fistula, starvation, vomiting" } },
            { test: "Progesterone (Female), Follicular phase", conventionalUnits: "<50 ng/dL", siUnits: "0.5-2.2 nmol/L", etiology: { high: "Adrenal hyperplasia, choriocarcinoma of ovary, pregnancy, cysts of ovary", low: "Threatened abortion, hypogonadism, amenorrhea, ovarian tumor" } },
            { test: "Progesterone (Female), Luteal phase", conventionalUnits: "300-2500 ng/dL", siUnits: "6.4-79.5 nmol/L", etiology: { high: "Adrenal hyperplasia, choriocarcinoma of ovary, pregnancy, cysts of ovary", low: "Threatened abortion, hypogonadism, amenorrhea, ovarian tumor" } },
            { test: "Progesterone (Female), Postmenopause", conventionalUnits: "<40 ng/dL", siUnits: "1.28 nmol/L", etiology: { high: "Adrenal hyperplasia, choriocarcinoma of ovary, pregnancy, cysts of ovary", low: "Threatened abortion, hypogonadism, amenorrhea, ovarian tumor" } },
            { test: "Prostate-specific antigen (PSA)", conventionalUnits: "<4.0 ng/mL", siUnits: "<4.0 mcg/L", etiology: { high: "Prostate cancer, prostatitis, benign prostatic hypertrophy", low: "" } },
            { test: "Proteins, Total", conventionalUnits: "6.4-8.3 g/dL", siUnits: "64-83 g/L", etiology: { high: "Burns, cirrhosis (globulin fraction), dehydration", low: "Liver disease, malabsorption" } },
            { test: "Proteins, Albumin", conventionalUnits: "3.5-5.0 g/dL", siUnits: "35-50 g/L", etiology: { high: "Burns, cirrhosis (globulin fraction), dehydration", low: "Liver disease, malabsorption" } },
            { test: "Proteins, Globulin", conventionalUnits: "2.3-3.4 g/dL", siUnits: "23-34 g/L", etiology: { high: "Multiple myeloma (globulin fraction), shock, vomiting", low: "Malnutrition, nephrotic syndrome, proteinuria, renal disease, severe burns" } },
            { test: "Albumin/globulin ratio", conventionalUnits: "1.5:1-2.5:1", siUnits: "1.5:1-2.5:1", etiology: { high: "Multiple myeloma (globulin fraction), shock, vomiting", low: "Malnutrition, nephrotic syndrome, proteinuria, renal disease, severe burns" } },
            { test: "Sodium", conventionalUnits: "136-145 mEq/L", siUnits: "136-145 mmol/L", etiology: { high: "Dehydration, impaired renal function, primary aldosteronism, corticosteroid therapy", low: "Addison's disease, diabetic ketoacidosis, diuretic therapy, excessive loss from GI tract, excessive perspiration, water intoxication" } },
            { test: "Testosterone (total)", conventionalUnits: "Male: 280-1080 ng/dL, Female: <70 ng/dL", siUnits: "Male: 280-1080 ng/dL, Female: <70 ng/dL", etiology: { high: "Polycystic ovary, virilizing tumors", low: "Hypofunction of testes, hypogonadism" } },
            { test: "T₄ (thyroxine), total", conventionalUnits: "Male: 4-12 mcg/dL, Female: 5-12 mcg/dL", siUnits: "Male: 59-135 nmol/L, Female: 71-142 nmol/L", etiology: { high: "Hyperthyroidism, thyroiditis, hepatitis, Graves' disease, thyroid cancer", low: "Cretinism, hypothyroidism, myxedema, Cushing syndrome, renal failure" } },
            { test: "T₄ (thyroxine), free", conventionalUnits: "0.8-2.8 ng/dL", siUnits: "10-36 pmol/L", etiology: { high: "Hyperthyroidism", low: "Hypothyroidism" } },
            { test: "T₃ uptake", conventionalUnits: "24%-34%", siUnits: "0.24-0.34", etiology: { high: "Hyperthyroidism", low: "Hypothyroidism" } },
            { test: "T₃ (triiodothyronine), total", conventionalUnits: "Age 20-50: 70-205 ng/dL, Age >50: 40-180 ng/dL", siUnits: "1.2-3.4 nmol/L, 0.60-2.8 nmol/L", etiology: { high: "Hyperthyroidism", low: "Hypothyroidism" } },
            { test: "Thyroid-stimulating hormone (TSH)", conventionalUnits: "2.0-10 µU/mL", siUnits: "2.0-10 mU/L", etiology: { high: "Myxedema, primary hypothyroidism", low: "Secondary hypothyroidism, hyperthyroidism" } },
            { test: "Aspartate aminotransferase (AST)", conventionalUnits: "0-35 U/L", siUnits: "0-0.58 µkat/L", etiology: { high: "Liver disease, myocardial infarction, pulmonary infarction, acute hepatitis", low: "Acute renal disease, diabetic ketoacidosis" } },
            { test: "Alanine aminotransferase (ALT)", conventionalUnits: "4-36 U/L", siUnits: "4-36 U/L", etiology: { high: "Liver disease, shock", low: "" } },
            { test: "Transferrin", conventionalUnits: "Male: 215-365 mg/dL, Female: 250-380 mg/dL", siUnits: "Male: 2.15-3.65 g/L, Female: 2.5-3.8 g/L", etiology: { high: "Iron-deficiency anemia, polycythemia vera", low: "Cirrhosis, pernicious anemia, sickle cell disease" } },
            { test: "Transferrin saturation (%)", conventionalUnits: "Male: 20%-50%, Female: 15%-50%", siUnits: "Male: 20%-50%, Female: 15%-50%", etiology: { high: "Hemolytic anemia, iron overdose", low: "Malnutrition" } },
            { test: "Triglycerides", conventionalUnits: "Male: 40-160 mg/dL, Female: 35-135 mg/dL", siUnits: "Male: 0.45-1.81 g/L, Female: 0.40-1.52 g/L", etiology: { high: "Diabetes, hyperlipidemia, hypothyroidism, liver disease", low: "Malnutrition" } },
            { test: "Troponin T (cTnT)", conventionalUnits: "<0.1 ng/mL", siUnits: "<0.1 mcg/L", etiology: { high: "Myocardial infarction, myocardial injury", low: "" } },
            { test: "Troponin I (cTnI)", conventionalUnits: "<0.03 ng/mL", siUnits: "<0.03 mcg/L", etiology: { high: "Myocardial infarction, myocardial injury", low: "" } },
            { test: "Urea nitrogen (BUN)", conventionalUnits: "10-20 mg/dL", siUnits: "3.6-7.1 mmol/L", etiology: { high: "Increase in protein catabolism (fever, sepsis, stress), renal disease, heart failure, myocardial infarction", low: "Malnutrition, severe liver damage" } },
            { test: "Uric acid", conventionalUnits: "Male: 4.0-8.5 mg/dL, Female: 2.7-7.3 mg/dL", siUnits: "Male: 0.24-0.51 mmol/L, Female: 0.16-0.43 mmol/L", etiology: { high: "Gout, gross tissue destruction, high-protein weight reduction diet, leukemia, renal failure", low: "Administration of uricosuric drugs" } },
            { test: "Vitamin B₁₂ (cobalamin)", conventionalUnits: "160-950 pg/mL", siUnits: "118-701 pmol/L", etiology: { high: "Chronic myeloid leukemia", low: "Strict vegetarianism, malabsorption syndrome, pernicious anemia, total or partial gastrectomy" } },
            { test: "Vitamin C (ascorbic acid)", conventionalUnits: "0.4-2.0 mg/dL", siUnits: "23-114 µmol/L", etiology: { high: "Excessive ingestion of vitamin C", low: "Connective tissue disorders, hepatic disease, renal disease, rheumatic fever, vitamin C deficiency" } },
            { test: "Vitamin D", conventionalUnits: "25-80 ng/dL", siUnits: "25-80 ng/dL", etiology: { high: "Excess dietary supplement", low: "Liver disease, malabsorption syndromes, osteoporosis, renal disease" } }
        ]
    },
    {
        title: "Hematology",
        icon: "🔬",
        tableId: "table-c2",
        values: [
            { test: "Bleeding time", conventionalUnits: "60-540 sec", siUnits: "60-540 sec", etiology: { high: "Aspirin ingestion, ineffective platelet function, thrombocytopenia, vascular disease, von Willebrand disease", low: "" } },
            { test: "Activated partial thromboplastin time (aPTT)", conventionalUnits: "30-40 sec", siUnits: "30-40 sec", etiology: { high: "Deficiency of factors I, II, V, VIII, IX, X, XI, XII, hemophilia, heparin therapy, liver disease", low: "Early DIC, extensive cancer" } },
            { test: "Prothrombin time (protime, PT)", conventionalUnits: "11-12.5 sec", siUnits: "11-12.5 sec", etiology: { high: "Deficiency of factors I, II, V, VII, and X, liver disease, vitamin K deficiency, warfarin therapy", low: "" } },
            { test: "Fibrinogen", conventionalUnits: "200-400 mg/dL", siUnits: "2-4 g/L", etiology: { high: "Burns (after first 36 hr), inflammatory disease, stroke, myocardial infarction", low: "Burns (during first 36 hr), DIC, severe liver disease, malnutrition" } },
            { test: "Fibrin split (degradation) products", conventionalUnits: "<10 mcg/mL", siUnits: "<10 mg/L", etiology: { high: "Acute DIC, massive hemorrhage, primary fibrinolysis", low: "" } },
            { test: "D-Dimer", conventionalUnits: "<250 ng/mL", siUnits: "<250 mcg/L", etiology: { high: "DIC, myocardial infarction, VTE, unstable angina, cancer", low: "" } },
            { test: "Erythrocyte count (altitude dependent)", conventionalUnits: "Male: 4.7-6.1 x 10⁶/µL, Female: 4.2-5.4 x 10⁶/µL", siUnits: "Male: 4.7-6.1 x 10¹²/L, Female: 4.2-5.4 x 10¹²/L", etiology: { high: "Dehydration, high altitudes, polycythemia vera, severe COPD", low: "Anemia, leukemia, hemorrhage, cancer, chronic illness, kidney disease" } },
            { test: "Mean corpuscular volume (MCV)", conventionalUnits: "80-95 fL", siUnits: "80-95 fL", etiology: { high: "Alcoholism, liver disease, macrocytic anemia", low: "Microcytic anemia, thalassemia" } },
            { test: "Mean corpuscular hemoglobin (MCH)", conventionalUnits: "27-31 pg", siUnits: "27-31 pg", etiology: { high: "Macrocytic anemia", low: "Microcytic anemia" } },
            { test: "Mean corpuscular hemoglobin concentration (MCHC)", conventionalUnits: "32%-36%", siUnits: "32-36 g/dL", etiology: { high: "Spherocytosis", low: "Iron deficiency anemia, thalassemia" } },
            { test: "Erythrocyte sedimentation rate (ESR)", conventionalUnits: "<20 mm/hr (some gender variation)", siUnits: "<20 mm/hr (some gender variation)", etiology: { high: "Moderate increase: acute hepatitis, myocardial infarction, rheumatoid arthritis. Marked increase: acute and severe bacterial infections, cancer, pelvic inflammatory disease", low: "Malaria, severe liver disease, sickle cell anemia" } },
            { test: "Hematocrit (altitude dependent)", conventionalUnits: "Male: 42%-52%, Female: 37%-47%", siUnits: "Male: 0.42-0.52, Female: 0.37-0.47", etiology: { high: "Dehydration, high altitudes, polycythemia, COPD", low: "Anemia, hemorrhage, overhydration, some kidney disease" } },
            { test: "Hemoglobin (altitude dependent)", conventionalUnits: "Male: 14-18 g/dL, Female: 12-16 g/dL", siUnits: "Male: 140-180 g/L, Female: 120-160 g/L", etiology: { high: "COPD, high altitudes, polycythemia, dehydration, burns", low: "Anemia, hemorrhage, kidney disease, cancer" } },
            { test: "Hemoglobin, glycosylated (A1C)", conventionalUnits: "4.0%-5.6%", siUnits: "4.0%-5.6%", etiology: { high: "Diabetes, pre-diabetes", low: "Sickle cell anemia, renal failure, pregnancy" } },
            { test: "Platelets (thrombocytes)", conventionalUnits: "150-400 x 10³/µL", siUnits: "150-400 x 10⁹/L", etiology: { high: "Acute infections, chronic granulocytic leukemia, chronic pancreatitis, cirrhosis, collagen disorders, polycythemia, postsplenectomy", low: "Acute leukemia, DIC, thrombocytopenic purpura" } },
            { test: "Reticulocyte count", conventionalUnits: "0.5%-2.0% of RBC", siUnits: "0.5%-2.0% of RBC", etiology: { high: "Hemolytic anemia, polycythemia vera", low: "Hypoproliferative anemias, macrocytic anemia, microcytic anemia" } },
            { test: "White blood cell count", conventionalUnits: "5000-10000/mm³", siUnits: "5.0-10.0 x 10⁹/L", etiology: { high: "Inflammatory and infectious processes, leukemia", low: "Aplastic anemia, effects of chemotherapy and irradiation" } },
            { test: "WBC, Segmented neutrophils", conventionalUnits: "55%-70%", siUnits: "0.55-0.70", etiology: { high: "Bacterial infections, collagen diseases, Hodgkin's lymphoma", low: "Aplastic anemia, viral infections" } },
            { test: "WBC, Band neutrophils", conventionalUnits: "0-8%", siUnits: "0-0.08", etiology: { high: "Acute infections", low: "" } },
            { test: "WBC, Lymphocytes", conventionalUnits: "20%-40%", siUnits: "0.20-0.40", etiology: { high: "Chronic infections, lymphocytic leukemia, mononucleosis, viral infections", low: "Corticosteroid therapy, whole body radiation" } },
            { test: "WBC, Monocytes", conventionalUnits: "2%-8%", siUnits: "0.02-0.08", etiology: { high: "Chronic inflammatory disorders, malaria, monocytic leukemia, acute infections, Hodgkin's lymphoma", low: "" } },
            { test: "WBC, Eosinophils", conventionalUnits: "1%-4%", siUnits: "0.01-0.04", etiology: { high: "Allergic reactions, eosinophilic and chronic granulocytic leukemia, parasitic disorders, Hodgkin's lymphoma", low: "Corticosteroid therapy" } },
            { test: "WBC, Basophils", conventionalUnits: "0.5%-1%", siUnits: "0.005-0.01", etiology: { high: "Hypothyroidism, ulcerative colitis, myeloproliferative diseases", low: "Hyperthyroidism, stress" } }
        ]
    },
    {
        title: "Serology-Immunology",
        icon: "🛡️",
        tableId: "table-c3",
        values: [
            { test: "Antinuclear antibody (ANA)", conventionalUnits: "Negative at 1:40 dilution", siUnits: "Negative at 1:40 dilution", etiology: { high: "Chronic hepatitis, rheumatoid arthritis, scleroderma, systemic lupus erythematosus", low: "" } },
            { test: "Anti-DNA antibody", conventionalUnits: "<5 IU/mL", siUnits: "<5 IU/mL", etiology: { high: "Systemic lupus erythematosus", low: "" } },
            { test: "Anti-Sm (Smith)", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Systemic lupus erythematosus", low: "" } },
            { test: "C-reactive protein (CRP)", conventionalUnits: "<1.0 mg/dL", siUnits: "<10.0 mg/L", etiology: { high: "Acute infections, any inflammatory condition, widespread cancer", low: "" } },
            { test: "Carcinoembryonic antigen (CEA)", conventionalUnits: "Nonsmoker: <3 ng/mL, Smoker: <5 ng/mL", siUnits: "Nonsmoker: <3 mcg/L, Smoker: <5 mcg/L", etiology: { high: "Cancer of colon, liver, pancreas, cigarette smoking; inflammatory bowel disease", low: "" } },
            { test: "Complement, total hemolytic (CH₅₀)", conventionalUnits: "30-75 U/mL", siUnits: "30-75 U/mL", etiology: { high: "Cancer, ulcerative colitis", low: "Bacterial endocarditis, glomerulonephritis, rheumatoid arthritis, systemic lupus erythematosus" } },
            { test: "Direct Coombs or direct antihuman globulin test (DAT)", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Acquired hemolytic anemia, drug reactions, transfusion reactions", low: "" } },
            { test: "Fluorescent treponemal antibody absorption (FTA-Abs)", conventionalUnits: "Negative or nonreactive", siUnits: "Negative or nonreactive", etiology: { high: "Syphilis", low: "" } },
            { test: "Hepatitis A antibody", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Hepatitis A", low: "" } },
            { test: "Hepatitis B surface antigen (HBsAg)", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Hepatitis B", low: "" } },
            { test: "Hepatitis C antibody", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Hepatitis C", low: "" } },
            { test: "Monospot or monotest", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Infectious mononucleosis", low: "" } },
            { test: "Rheumatoid factor (RF)", conventionalUnits: "Negative or titer <1:17", siUnits: "Negative or titer <1:17", etiology: { high: "Rheumatoid arthritis, Sjögren's syndrome, systemic lupus erythematosus", low: "" } },
            { test: "RPR", conventionalUnits: "Negative or nonreactive", siUnits: "Negative or nonreactive", etiology: { high: "Leprosy, malaria, rheumatoid arthritis, systemic lupus erythematosus, syphilis", low: "" } },
            { test: "VDRL", conventionalUnits: "Negative or nonreactive", siUnits: "Negative or nonreactive", etiology: { high: "Syphilis", low: "" } }
        ]
    },
    {
        title: "Urine Chemistry",
        icon: "💧",
        tableId: "table-c4",
        values: [
            { test: "Acetone", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Diabetes, high-fat and low-carbohydrate diets, starvation", low: "" } },
            { test: "Aldosterone", specimen: "24 hr", conventionalUnits: "2-26 mcg/day", siUnits: "6-72 nmol/day", etiology: { high: "Primary aldosteronism: adrenocortical tumors. Secondary aldosteronism: cirrhosis, heart failure, hyperkalemia, hyponatremia", low: "ACTH deficiency, Addison's disease, corticosteroid therapy, hypokalemia" } },
            { test: "Amylase", specimen: "24 hr", conventionalUnits: "<5000 Somogyi U/day", siUnits: "6.5-48.1 U/hr", etiology: { high: "Acute pancreatitis", low: "" } },
            { test: "Bence Jones protein", specimen: "Random", conventionalUnits: "<0.68 mg/dL", siUnits: "<0.68 mg/dL", etiology: { high: "Multiple myeloma", low: "" } },
            { test: "Bilirubin", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Liver disorders", low: "" } },
            { test: "Catecholamines, Epinephrine", specimen: "24 hr", conventionalUnits: "<20 mcg/day", siUnits: "<109 nmol/day", etiology: { high: "Heart failure, pheochromocytoma, progressive muscular dystrophy", low: "" } },
            { test: "Catecholamines, Norepinephrine", specimen: "24 hr", conventionalUnits: "<100 mcg/day", siUnits: "<590 nmol/day", etiology: { high: "Heart failure, pheochromocytoma, progressive muscular dystrophy", low: "" } },
            { test: "Cortisol", specimen: "24 hr", conventionalUnits: "<100 mcg/day", siUnits: "<276 nmol/day", etiology: { high: "Adrenal cancer, Cushing syndrome, hyperthyroidism, obesity, stress", low: "Addison's disease, hypothyroidism, liver disease" } },
            { test: "Creatinine clearance", specimen: "24 hr", conventionalUnits: "Male: 107-139 mL/min, Female: 87-107 mL/min", siUnits: "Male: 1.78-2.32 mL/sec, Female: 1.45-1.78 mL/sec", etiology: { high: "Exercise, pregnancy", low: "Cirrhosis, heart failure, renal disease" } },
            { test: "Estrogens, Female (Nonpregnant)", specimen: "24 hr", conventionalUnits: "4-60 mcg/day", siUnits: "4-60 mcg/day", etiology: { high: "Gonadal or adrenal tumor", low: "Endocrine disturbance, ovarian dysfunction, menopause" } },
            { test: "Estrogens, Female (Postmenopause)", specimen: "24 hr", conventionalUnits: "<20 mcg/day", siUnits: "<20 mcg/day", etiology: { high: "Gonadal or adrenal tumor", low: "Endocrine disturbance, ovarian dysfunction, menopause" } },
            { test: "Estrogens, Male", specimen: "24 hr", conventionalUnits: "4-25 mcg/day", siUnits: "4-25 mcg/day", etiology: { high: "Gonadal or adrenal tumor", low: "" } },
            { test: "Glucose", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Diabetes, pituitary disorders", low: "" } },
            { test: "Hemoglobin", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Extensive burns, glomerulonephritis, hemolytic anemia, hemolytic transfusion reaction", low: "" } },
            { test: "5-Hydroxyindole acetic acid (5-HIAA)", specimen: "24 hr", conventionalUnits: "2-8 mg/day", siUnits: "10-40 µmol/day", etiology: { high: "Malignant carcinoid syndrome", low: "" } },
            { test: "Ketones", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Diabetes, starvation, dehydration", low: "" } },
            { test: "Metanephrine", specimen: "24 hr", conventionalUnits: "<1.3 mg/day", siUnits: "<7 µmol/day", etiology: { high: "Pheochromocytoma", low: "" } },
            { test: "Myoglobin", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Crushing injuries, electric injuries, extreme physical exertion", low: "" } },
            { test: "Osmolality", specimen: "Random", conventionalUnits: "50-1200 mOsm/kg", siUnits: "50-1200 mmol/kg", etiology: { high: "Heart failure, liver disease, shock, SIADH", low: "Aldosteronism, diabetes insipidus, hypokalemia, pyelonephritis" } },
            { test: "pH", specimen: "Random", conventionalUnits: "4.6-8.0", siUnits: "4.6-8.0", etiology: { high: "Urinary tract infection, urine allowed to stand at room temperature", low: "Respiratory or metabolic acidosis" } },
            { test: "Protein", specimen: "Random", conventionalUnits: "0-8 mg/dL", siUnits: "0-8 mg/dL", etiology: { high: "Acute and chronic renal disease, heart failure", low: "" } },
            { test: "Protein (quantitative)", specimen: "24 hr", conventionalUnits: "50-80 mg/day", siUnits: "50-80 mg/day", etiology: { high: "Heart failure, inflammatory process of urinary tract, nephritis, nephrosis, strenuous exercise", low: "" } },
            { test: "Sodium", specimen: "24 hr", conventionalUnits: "40-220 mEq/day", siUnits: "40-220 mmol/day", etiology: { high: "Acute tubular necrosis", low: "Hyponatremia" } },
            { test: "Specific gravity", specimen: "Random", conventionalUnits: "1.005-1.030", siUnits: "1.005-1.030", etiology: { high: "Albuminuria, dehydration, glycosuria, fever", low: "Diabetes insipidus, hypothermia, diuresis" } },
            { test: "Uric acid", specimen: "24 hr", conventionalUnits: "250-750 mg/day", siUnits: "1.48-4.43 mmol/day", etiology: { high: "Gout, leukemia", low: "Nephritis" } },
            { test: "Urobilinogen", specimen: "Random", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Hemolytic disease, hepatic parenchymal cell damage, liver disease", low: "Complete bile duct obstruction" } },
            { test: "Vanillylmandelic acid", specimen: "24 hr", conventionalUnits: "<6.8 mg/day", siUnits: "<35 µmol/day", etiology: { high: "Pheochromocytoma", low: "Corticosteroid therapy" } }
        ]
    },
    {
        title: "Fecal Analysis",
        icon: "💩",
        tableId: "table-c5",
        values: [
            { test: "Fecal fat", conventionalUnits: "2-6 g/24 hr", siUnits: "7-21 mmol/day", etiology: { high: "Common bile duct obstruction, malabsorption syndrome, pancreatic disease", low: "" } },
            { test: "Mucus", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Mucous colitis, spastic constipation", low: "" } },
            { test: "Pus", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Chronic bacillary dysentery, chronic ulcerative colitis, localized abscesses", low: "" } },
            { test: "Blood", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Anal fissures, gastrointestinal cancer, hemorrhoids, inflammatory bowel disease, peptic ulcer disease", low: "" }, notes: "Ingestion of meat may produce false-positive results. Patient may be placed on a meat-free diet for 3 days before the test." },
            { test: "Color, Brown", conventionalUnits: "", siUnits: "", etiology: { high: "Various color depending on diet", low: "" } },
            { test: "Color, Clay", conventionalUnits: "", siUnits: "", etiology: { high: "Biliary obstruction, presence of barium sulfate", low: "" } },
            { test: "Color, Tarry", conventionalUnits: "", siUnits: "", etiology: { high: "More than 100 mL of blood in gastrointestinal tract", low: "" } },
            { test: "Color, Red", conventionalUnits: "", siUnits: "", etiology: { high: "Blood in large intestine", low: "" } },
            { test: "Color, Black", conventionalUnits: "", siUnits: "", etiology: { high: "Blood in upper gastrointestinal tract, iron medication", low: "" } }
        ]
    },
    {
        title: "Cerebrospinal Fluid Analysis",
        icon: "🧠",
        tableId: "table-c6",
        values: [
            { test: "Pressure", conventionalUnits: "<20 mm H₂O", siUnits: "<20 mm H₂O", etiology: { high: "Hemorrhage, intracranial tumor, meningitis", low: "Head injury, spinal tumor, subdural hematoma" } },
            { test: "Blood", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Intracranial hemorrhage", low: "" } },
            { test: "WBC (age dependent)", conventionalUnits: "0-5 cells/µL", siUnits: "0-5 x 10⁶ cells/L", etiology: { high: "CNS infection or inflammation", low: "" } },
            { test: "RBC", conventionalUnits: "Negative", siUnits: "Negative", etiology: { high: "Intracranial hemorrhage", low: "" } },
            { test: "Chloride", conventionalUnits: "700-750 mg/dL", siUnits: "118-132 mmol/L", etiology: { high: "Uremia", low: "CNS bacterial infection" } },
            { test: "Glucose", conventionalUnits: "50-75 mg/dL", siUnits: "2.2-3.9 mmol/L", etiology: { high: "CNS viral infection, diabetes", low: "Bacterial infection, CNS tuberculosis" } },
            { test: "Protein, Lumbar", conventionalUnits: "15-45 mg/dL", siUnits: "0.15-0.45 g/L", etiology: { high: "Guillain-Barré syndrome, poliomyelitis, trauma", low: "" } },
            { test: "Protein, Cisternal", conventionalUnits: "15-25 mg/dL", siUnits: "0.15-0.25 g/L", etiology: { high: "CNS syphilis", low: "" } },
            { test: "Protein, Ventricular", conventionalUnits: "5-15 mg/dL", siUnits: "0.05-0.15 g/L", etiology: { high: "Acute meningitis, brain tumor, chronic CNS infection, multiple sclerosis", low: "" } }
        ]
    }
];



// --- DOM Elements (shared) ---
const homeContentDiv = document.getElementById('homeContent') as HTMLElement | null;
const exploreContentDiv = document.getElementById('exploreContent') as HTMLElement | null;
const studyContentDiv = document.getElementById('studyContent') as HTMLElement | null;
const labsContentDiv = document.getElementById('labsContent') as HTMLElement | null;

const bottomNavItems = document.querySelectorAll('.bottom-nav-item');
const appModal = document.getElementById('appModal') as HTMLElement | null;
const modalContentWrapper = document.getElementById('modalContentWrapper') as HTMLElement | null;
const modalTitle = document.getElementById('modalTitle') as HTMLElement | null;
const modalBody = document.getElementById('modalBody') as HTMLElement | null;
const modalFooter = document.getElementById('modalFooter') as HTMLElement | null;
const modalCloseBtn = document.getElementById('modalCloseBtn') as HTMLElement | null;

let currentCalculator: Calculator | null = null;
let dynamicListCounters: Record<string, number> = {};


// --- General Utility Functions ---
function sanitizeHTML(str: string): string {
    const temp = document.createElement('div');
    temp.textContent = str;
    return temp.innerHTML;
}

function openModal(title: string, bodyHtml: string, footerHtml = '', hideCalcBtns = true) {
    if (!appModal || !modalTitle || !modalBody || !modalFooter || !modalContentWrapper) return;

    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;
    modalFooter.innerHTML = footerHtml;

    if (hideCalcBtns) {
        const calcBtn = document.getElementById('modal-calculate-btn');
        const clearBtn = document.getElementById('modal-clear-btn');
        if(calcBtn) calcBtn.classList.add('hidden');
        if(clearBtn) clearBtn.classList.add('hidden');
    } else {
         const calcBtn = document.getElementById('modal-calculate-btn');
        const clearBtn = document.getElementById('modal-clear-btn');
        if(calcBtn) calcBtn.classList.remove('hidden');
        if(clearBtn) clearBtn.classList.remove('hidden');
    }

    appModal.classList.remove('hidden');
    appModal.classList.add('flex');
    document.body.style.overflow = 'hidden';

    setTimeout(() => {
        modalContentWrapper.classList.add('scale-100', 'opacity-100');
        modalContentWrapper.classList.remove('scale-95', 'opacity-0');
    }, 10);
}

function closeModal() {
    if (!appModal || !modalContentWrapper || !modalTitle || !modalBody || !modalFooter) return;
    
    modalContentWrapper.classList.add('scale-95', 'opacity-0');
    modalContentWrapper.classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
        appModal.classList.add('hidden');
        appModal.classList.remove('flex');
        document.body.style.overflow = '';
        // Reset modal content
        modalTitle.textContent = '';
        modalBody.innerHTML = '';
        modalFooter.innerHTML = '';
    }, 300); // Match transition duration
}


// --- Calculator Tab Logic ---

function renderCalculatorWidgetsPage(filteredData: CalculatorCategory[] = allCalculatorsData) {
    const calculatorWidgetsHost = document.getElementById('calculatorWidgetsHost');
    const noResultsDiv = document.getElementById('no-calc-results');

    if (!calculatorWidgetsHost || !noResultsDiv) return;

    calculatorWidgetsHost.innerHTML = '';
    noResultsDiv.classList.toggle('hidden', filteredData.length > 0);

    let cardCounter = 0;
    filteredData.forEach(category => {
        const categorySection = document.createElement('section');
        categorySection.className = 'mb-12';

        const categoryTitleEl = document.createElement('h2');
        categoryTitleEl.className = 'text-2xl font-bold text-text-secondary mb-6 pb-2 border-b border-b-glass-border flex items-center gap-3';
        categoryTitleEl.innerHTML = `<span class="text-3xl">${category.categoryIcon || '📁'}</span> ${category.category}`;
        categorySection.appendChild(categoryTitleEl);

        const widgetsGrid = document.createElement('div');
        widgetsGrid.className = 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 sm:gap-6';
        
        category.calculators.forEach(calc => {
            const widget = document.createElement('button');
            widget.type = 'button';
            widget.className = 'card-glass p-5 flex flex-col justify-center items-start text-left stagger-fade-in';
            widget.style.animationDelay = `${cardCounter * 50}ms`;
            widget.setAttribute('data-calculator-id', calc.id);
            widget.setAttribute('aria-label', `Open ${calc.name} calculator`);
            
            widget.innerHTML = `
                <h3 class="font-semibold text-lg text-text-primary leading-tight">${calc.name}</h3>
                <p class="text-sm text-text-accent mt-1">${category.category}</p>
            `;

            widget.onclick = () => setActiveCalculator(calc.id);
            widgetsGrid.appendChild(widget);
            cardCounter++;
        });
        categorySection.appendChild(widgetsGrid);
        calculatorWidgetsHost.appendChild(categorySection);
    });
}

function setActiveCalculator(calculatorId: string) {
    const calculator = allCalculatorsData.flatMap(cat => cat.calculators).find(c => c.id === calculatorId);
    if (!calculator) return;

    currentCalculator = calculator;
    
    const modalFooterContent = `
        <button id="modal-calculate-btn" class="btn btn-primary w-full sm:w-auto flex-grow font-semibold py-3 px-6 rounded-lg shadow-lg">Calculate</button>
        <button id="modal-clear-btn" class="btn btn-clear w-full sm:w-auto font-semibold py-3 px-6 rounded-lg">Clear</button>
    `;
    openModal(calculator.name, '<form id="calculator-form" novalidate><div id="modal-inputs" class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5"></div></form><div id="modal-result-card" class="mt-6 hidden"></div>', modalFooterContent, false);
    renderCalculatorUI(calculator);

    // Attach listeners for calculate/clear AFTER modal content is rendered
    const calcForm = document.getElementById('calculator-form');
    const calculateBtn = document.getElementById('modal-calculate-btn');
    const clearBtn = document.getElementById('modal-clear-btn');

    if(calcForm) calcForm.addEventListener('submit', (e) => { e.preventDefault(); if (currentCalculator) handleCalculate(currentCalculator); });
    if(calculateBtn) calculateBtn.addEventListener('click', (e) => { e.preventDefault(); if (currentCalculator) handleCalculate(currentCalculator); });
    if(clearBtn) clearBtn.addEventListener('click', () => { if(currentCalculator) renderCalculatorUI(currentCalculator); });
}

function createInputField(inputDef: CalculatorInput): HTMLDivElement {
    const formGroupId = `form-group-${inputDef.id}`;
    let existingGroup = document.getElementById(formGroupId) as HTMLDivElement;
    if (existingGroup) {
        existingGroup.innerHTML = '';
    } else {
        existingGroup = document.createElement('div');
        existingGroup.id = formGroupId;
    }
    
    const isDynamicList = inputDef.type === 'dynamicList';
    existingGroup.className = isDynamicList ? 'md:col-span-2 mb-2' : 'mb-2';

    const label = document.createElement('label');
    label.htmlFor = inputDef.id;
    label.className = 'block text-sm font-medium mb-1.5';
    label.textContent = inputDef.label + (inputDef.unit ? ` (${inputDef.unit})` : '');
    existingGroup.appendChild(label);

    if (inputDef.type === 'select') {
        const select = document.createElement('select');
        select.id = inputDef.id;
        select.name = inputDef.id;
        select.className = 'input-glass w-full';
        (inputDef.options || []).forEach(opt => {
            const option = document.createElement('option');
            option.value = opt.value;
            option.textContent = opt.text;
            select.appendChild(option);
        });
        existingGroup.appendChild(select);
    } else if (isDynamicList) {
        const listContainerId = `${inputDef.id}-list`;
        dynamicListCounters[inputDef.id] = 0;

        const listDiv = document.createElement('div');
        listDiv.id = listContainerId;
        listDiv.className = 'space-y-3 mt-1';
        existingGroup.appendChild(listDiv);

        const addButton = document.createElement('button');
        addButton.type = 'button';
        addButton.textContent = `+ Add ${inputDef.listName} Item`;
        addButton.className = 'mt-2 text-sm py-1.5 px-3 bg-blue-600/50 hover:bg-blue-600/70 text-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-blue-500 transition-all';
        addButton.onclick = () => addDynamicListItem(inputDef.id, listContainerId);
        existingGroup.appendChild(addButton);

    } else {
        const input = document.createElement('input');
        input.type = inputDef.type;
        input.id = inputDef.id;
        input.name = inputDef.id;
        input.className = 'input-glass w-full';
        if (inputDef.placeholder) input.placeholder = inputDef.placeholder;
        if (inputDef.type === "number") {
            input.step = "any";
            input.oninput = (e) => (e.target as HTMLInputElement).classList.remove('input-error-border');
        }
        if(inputDef.type === 'date') {
            input.classList.add('appearance-none');
        }
        existingGroup.appendChild(input);
    }
    const errorSpanId = `${inputDef.id}-error`;
    const errorSpan = document.createElement('span');
    errorSpan.id = errorSpanId;
    errorSpan.className = 'input-error-message hidden mt-1';
    errorSpan.setAttribute('aria-live', 'assertive');
    existingGroup.appendChild(errorSpan);

    return existingGroup;
}

function addDynamicListItem(listBaseId: string, containerId: string) {
    const listContainer = document.getElementById(containerId);
    if (!listContainer) return;

    const itemId = dynamicListCounters[listBaseId]++;
    
    const itemDiv = document.createElement('div');
    itemDiv.className = 'flex items-center space-x-2 p-2.5 border border-glass-border rounded-lg bg-slate-900/50';
    itemDiv.id = `${listBaseId}-item-${itemId}`;

    const descInput = document.createElement('input');
    descInput.type = 'text';
    descInput.name = `${listBaseId}_description_${itemId}`;
    descInput.placeholder = 'Item Description (e.g., Oral)';
    descInput.className = 'flex-grow input-glass !py-1.5';
    
    const amountInput = document.createElement('input');
    amountInput.type = 'number';
    amountInput.name = `${listBaseId}_amount_${itemId}`;
    amountInput.placeholder = 'Amount (mL)';
    amountInput.step = "any";
    amountInput.className = 'w-32 input-glass !py-1.5';
    amountInput.oninput = (e) => {
        const target = e.target as HTMLInputElement;
        if (parseFloat(target.value) < 0) target.classList.add('input-error-border');
        else target.classList.remove('input-error-border');
    };

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.innerHTML = '&times;';
    removeButton.setAttribute('aria-label', 'Remove item');
    removeButton.className = 'py-1 px-2.5 bg-red-600/50 hover:bg-red-600/80 text-white rounded-md text-xs font-bold focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-red-500 transition-all';
    removeButton.onclick = () => itemDiv.remove();

    itemDiv.appendChild(descInput);
    itemDiv.appendChild(amountInput);
    itemDiv.appendChild(removeButton);
    listContainer.appendChild(itemDiv);
    descInput.focus();
}

function renderCalculatorUI(calculator: Calculator) {
    const modalInputsDiv = document.getElementById('modal-inputs');
    const modalResultCardDiv = document.getElementById('modal-result-card');
    const form = document.getElementById('calculator-form') as HTMLFormElement | null;

    if (!modalInputsDiv || !modalResultCardDiv || !form) return;

    modalInputsDiv.innerHTML = '';
    modalResultCardDiv.innerHTML = '';
    modalResultCardDiv.classList.add('hidden');
    form.reset();
    
    (calculator.inputs || []).forEach(inputDef => {
        modalInputsDiv.appendChild(createInputField(inputDef));
    });
}

function clearErrorMessages() {
    document.querySelectorAll(`#calculator-form .input-error-message`).forEach(span => {
        span.textContent = '';
        span.classList.add('hidden');
    });
    document.querySelectorAll(`#calculator-form .input-error-border`).forEach(el => {
        el.classList.remove('input-error-border');
    });
}

function displayErrorMessage(inputFieldId: string, message: string) {
    const errorSpan = document.getElementById(`${inputFieldId}-error`);
    const inputEl = document.getElementById(inputFieldId);
    if (errorSpan) {
        errorSpan.textContent = message;
        errorSpan.classList.remove('hidden');
    }
    if (inputEl) {
        inputEl.classList.add('input-error-border');
        if(document.activeElement !== inputEl) inputEl.focus();
    }
}

// --- VISUALIZATION FUNCTIONS ---

function createDonutChart(score: number, params: VisualizationParams): HTMLDivElement {
    const { unit = '', maxScore, ranges } = params;
    const container = document.createElement('div');
    container.className = 'visualization-container my-4';

    const size = 160;
    const strokeWidth = 12;
    const radius = (size / 2) - (strokeWidth * 2);
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (score / (maxScore || 1)) * circumference;

    const range = ranges.find(r => score <= (r.till ?? r.max ?? 0)) || ranges[ranges.length - 1];
    const color = range.color;
    const label = range.label;

    const svgHTML = `
        <svg class="w-full h-auto" viewBox="0 0 ${size} ${size}">
            <circle class="donut-chart-track" stroke-width="${strokeWidth}" fill="transparent" r="${radius}" cx="${size/2}" cy="${size/2}" />
            <circle class="donut-chart-value" stroke="${color}" stroke-width="${strokeWidth}" fill="transparent" r="${radius}" cx="${size/2}" cy="${size/2}"
                    style="stroke-dasharray: ${circumference}; stroke-dashoffset: ${circumference}; transform: rotate(-90deg); transform-origin: 50% 50%;" />
            <text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" class="fill-current text-text-primary" font-size="28" font-weight="bold">
                ${score}<tspan font-size="16" class="fill-current text-text-accent">${unit ? ' ' + unit : `/${maxScore}`}</tspan>
            </text>
            <text x="50%" y="65%" dominant-baseline="middle" text-anchor="middle" class="fill-current" font-size="12" style="fill: ${color};" font-weight="600">
                ${label}
            </text>
        </svg>
    `;

    container.innerHTML = svgHTML;
    setTimeout(() => {
        const circle = container.querySelector('.donut-chart-value') as SVGCircleElement | null;
        if (circle) circle.style.strokeDashoffset = String(offset);
    }, 100);

    return container;
}

function createLinearGauge(value: number, params: VisualizationParams): HTMLDivElement {
    const { unit = '', ranges, displayMin, displayMax } = params;
    const container = document.createElement('div');
    container.className = 'visualization-container my-4 py-2';
    
    const totalRange = (displayMax ?? 100) - (displayMin ?? 0);
    const valuePercent = ((value - (displayMin ?? 0)) / totalRange) * 100;
    const range = ranges.find(r => value < (r.max ?? Infinity)) || ranges[ranges.length - 1];
    const label = range.label;
    const color = range.color;

    let lastStop = displayMin ?? 0;
    const rangeSegments = ranges.map(r => {
        const segmentStart = Math.max(displayMin ?? 0, (ranges.indexOf(r) > 0 ? (ranges[ranges.indexOf(r) - 1].max ?? 0) : (displayMin ?? 0)));
        const width = (((r.max ?? displayMax ?? 100) - segmentStart) / totalRange) * 100;
        lastStop = r.max ?? 0;
        return `<div class="h-full" style="width: ${width}%; background-color: ${r.color};"></div>`;
    }).join('');

    const gaugeHTML = `
        <div class="relative w-full">
            <div class="absolute -top-7 text-center transition-all" style="left: ${valuePercent}%;">
                <div class="text-sm font-bold" style="color: ${color};">${value} ${unit}</div>
                <div class="w-0 h-0 border-l-4 border-l-transparent border-r-4 border-r-transparent border-t-4 mx-auto" style="border-top-color: ${color};"></div>
            </div>
            <div class="h-2.5 w-full linear-gauge-track rounded-full flex overflow-hidden">${rangeSegments}</div>
            <div class="flex justify-between text-xs text-text-accent mt-1.5">
                <span>${displayMin}</span>
                <span>${displayMax}</span>
            </div>
        </div>
    `;
    container.innerHTML = gaugeHTML;
    return container;
}

function createBarChart(data: Record<string, any>): HTMLDivElement {
    const intake = parseFloat(data.totalIntake);
    const output = parseFloat(data.totalOutput);
    const balance = parseFloat(data.finalBalance);

    const container = document.createElement('div');
    container.className = 'visualization-container my-4';

    const maxVal = Math.max(intake, output, 100); // ensure a minimum height
    const intakeHeight = (intake / maxVal) * 100;
    const outputHeight = (output / maxVal) * 100;
    const balanceColor = balance >= 0 ? 'text-green-400' : 'text-red-400';
    const balanceSign = balance >= 0 ? '+' : '';

    const chartHTML = `
        <div class="relative h-48 w-full">
            <div class="absolute top-0 left-0 w-full h-full">
                <div class="h-1/4 w-full border-b border-dashed border-white/10"></div>
                <div class="h-1/4 w-full border-b border-dashed border-white/10"></div>
                <div class="h-1/4 w-full border-b border-dashed border-white/10"></div>
                <div class="h-1/4 w-full"></div>
            </div>
            <div class="absolute bottom-0 left-0 right-0 flex justify-around items-end h-full px-4">
                <div class="w-1/3 text-center">
                    <div class="font-bold text-sm text-blue-300">${intake} mL</div>
                    <div class="bar-chart-bar w-1/2 mx-auto bg-blue-500 rounded-t-md" style="height: 0%;"></div>
                    <div class="text-xs font-semibold text-text-secondary mt-1">Intake</div>
                </div>
                <div class="w-1/3 text-center">
                    <div class="font-bold text-sm text-red-300">${output} mL</div>
                    <div class="bar-chart-bar w-1/2 mx-auto bg-red-500 rounded-t-md" style="height: 0%;"></div>
                    <div class="text-xs font-semibold text-text-secondary mt-1">Output</div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <div class="text-sm text-text-accent">Fluid Balance</div>
            <div class="text-2xl font-bold ${balanceColor}">${balanceSign}${balance} mL</div>
        </div>
    `;

    container.innerHTML = chartHTML;
    setTimeout(() => {
        const bars = container.querySelectorAll('.bar-chart-bar');
        (bars[0] as HTMLElement).style.height = `${intakeHeight}%`;
        (bars[1] as HTMLElement).style.height = `${outputHeight}%`;
    }, 100);

    return container;
}


function handleCalculate(calculator: Calculator) {
    const calculatorForm = document.getElementById('calculator-form') as HTMLFormElement | null;
    const modalResultCard = document.getElementById('modal-result-card');
    if (!calculatorForm || !modalResultCard) return;

    const formData = new FormData(calculatorForm);
    const values: Record<string, any> = {};
    let firstErrorFieldId: string | null = null;
    let hasError = false;

    clearErrorMessages();

    for (const inputDef of (calculator.inputs || [])) {
        if (inputDef.type === 'dynamicList') {
            values[inputDef.id] = [];
            const listContainer = document.getElementById(`${inputDef.id}-list`);
            if (listContainer) {
                const items = listContainer.querySelectorAll(':scope > div');
                items.forEach((itemDiv, index) => {
                    const descInput = itemDiv.querySelector('input[type="text"]') as HTMLInputElement;
                    const amountInput = itemDiv.querySelector('input[type="number"]') as HTMLInputElement;
                    const description = descInput ? descInput.value.trim() : `Item ${index + 1}`;
                    const amountStr = amountInput ? amountInput.value : '';
                    
                    if (amountStr.trim() === '' || isNaN(parseFloat(amountStr)) || parseFloat(amountStr) < 0) {
                        if (amountInput) amountInput.classList.add('input-error-border');
                        hasError = true;
                        if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                    } else {
                        if (amountInput) amountInput.classList.remove('input-error-border');
                    }
                    values[inputDef.id].push({ description, amount: amountStr });
                });
                if (calculator.id === 'fluidBalance' && hasError && firstErrorFieldId === inputDef.id) {
                    displayErrorMessage(inputDef.id, 'One or more amounts in the list are invalid, empty, or negative.');
                }
            }
        } else {
            const value = formData.get(inputDef.id) as string;
            values[inputDef.id] = value;
            if (inputDef.unit) values[`${inputDef.id}_unit`] = inputDef.unit;

            if (!value && inputDef.type !== 'select' && inputDef.type !== 'text') {
                displayErrorMessage(inputDef.id, 'This field is required.');
                if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                hasError = true;
            } else if (inputDef.type === 'number' && value && (isNaN(parseFloat(value)) || !isFinite(Number(value)) )) {
                displayErrorMessage(inputDef.id, 'Please enter a valid number.');
                if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                hasError = true;
            } else if (inputDef.type === 'date' && value) {
                const today = new Date(); today.setHours(0,0,0,0);
                const selectedDate = new Date(value + "T00:00:00Z");
                if (calculator.id === 'eddNaegeles' && selectedDate > today) {
                    displayErrorMessage(inputDef.id, 'LMP date cannot be in the future.');
                    if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                    hasError = true;
                }
            }
            if (inputDef.type === 'number' && value && parseFloat(value) < 0) {
                const generallyPositiveIds = ['desiredDose', 'doseOnHand', 'volumeVehicle', 'totalVolume', 'totalTimeHours', 'totalVolumeGtt', 'totalTimeMinutes', 'dropFactor', 'weightKg', 'heightCm', 'ageYearsCG', 'weightCrClCG', 'serumCreatinineCG', 'prescribedDosePerKg', 'weightPeds', 'dosesPerDay', 'weightFluidsPeds', 'weightUrinePeds', 'shiftDuration', 'sbpMap', 'dbpMap', 'weightBurn', 'tbsa', 'mapForCpp', 'pao2'];
                const nonNegativeIds = ['icp'];
                if (generallyPositiveIds.includes(inputDef.id)) {
                    displayErrorMessage(inputDef.id, 'Value must be positive.');
                    if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                    hasError = true;
                } else if (nonNegativeIds.includes(inputDef.id) && parseFloat(value) < 0) {
                    displayErrorMessage(inputDef.id, 'Value must be non-negative.');
                    if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                    hasError = true;
                }
            }
            if (inputDef.id === 'fio2' && value && (parseFloat(value) < 21 || parseFloat(value) > 100)) {
                displayErrorMessage(inputDef.id, 'FiO2 must be between 21% and 100%.');
                if(!firstErrorFieldId) firstErrorFieldId = inputDef.id;
                hasError = true;
            }
        }
    }
    
    if (hasError) return;

    const resultData = calculator.calculate(values);
    modalResultCard.innerHTML = '';

    if (resultData.error) {
        modalResultCard.innerHTML = `<p class="mt-4 p-3 bg-red-500/30 text-red-300 border border-red-500/50 rounded-lg text-sm">${resultData.error}</p>`;
    } else {
        const resultCard = document.createElement('div');
        resultCard.className = 'results-card-bg';

        const patientIconDiv = document.createElement('div');
        patientIconDiv.className = 'flex items-center mb-4';
        patientIconDiv.innerHTML = `
            <svg class="patient-icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" /></svg>
            <h3 class="text-xl font-semibold text-text-primary">${calculator.name} Results</h3>
        `;
        resultCard.appendChild(patientIconDiv);

        if(resultData.info && calculator.infoMessage) {
            resultCard.innerHTML += `<p class="mt-4 p-3 bg-blue-500/20 text-blue-200 border border-blue-500/30 rounded-lg text-sm">${sanitizeHTML(calculator.infoMessage)}</p>`;
        }

        if (calculator.visualizationType && !resultData.info) {
            let vizElement: HTMLElement | null = null;
            const vizParams = calculator.visualizationParams;

            if (calculator.visualizationType === 'donutChart' && vizParams) {
                const score = parseFloat(resultData[calculator.outputs[0].id]);
                vizElement = createDonutChart(score, vizParams);
            } else if (calculator.visualizationType === 'linearGauge' && vizParams) {
                const value = parseFloat(resultData[calculator.outputs[0].id]);
                vizElement = createLinearGauge(value, vizParams);
            } else if (calculator.visualizationType === 'barChart') {
                vizElement = createBarChart(resultData);
            }
            if(vizElement) resultCard.appendChild(vizElement);
        }

        if(calculator.outputs && calculator.outputs.length > 0 && calculator.visualizationType !== 'barChart') {
            const outputsContainer = document.createElement('div');
            outputsContainer.className = 'grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4';
            calculator.outputs.forEach(outputDef => {
                if (resultData[outputDef.id] !== undefined) {
                    const outputDiv = document.createElement('div');
                    outputDiv.className = 'bg-slate-900/50 p-3 rounded-lg text-center';
                    outputDiv.innerHTML = `
                        <div class="text-sm text-text-accent">${outputDef.label}</div>
                        <div class="text-xl font-bold results-strong-text-color">${sanitizeHTML(String(resultData[outputDef.id]))} ${outputDef.unit || ''}</div>
                    `;
                    outputsContainer.appendChild(outputDiv);
                }
            });
            resultCard.appendChild(outputsContainer);
        }
        
        const interpretation = calculator.interpretResult && !resultData.info ? calculator.interpretResult(resultData, values) : null;
        if (interpretation) {
            resultCard.innerHTML += `
                <h4 class="text-md font-semibold text-text-accent mt-5 mb-2">Interpretation:</h4>
                <p class="text-sm font-medium interpretation-bg p-3 rounded-lg">${sanitizeHTML(interpretation)}</p>`;
        }

        if (calculator.getCalculationBreakdown && !resultData.info) {
            resultCard.innerHTML += `
                <details class="mt-4">
                    <summary class="text-md font-semibold text-text-accent cursor-pointer">Calculation Breakdown</summary>
                    <div class="mt-2 text-sm space-y-1 breakdown-bg p-3 rounded-lg border border-glass-border">
                        ${calculator.getCalculationBreakdown(values, resultData)}
                    </div>
                </details>`;
        }
        
        modalResultCard.appendChild(resultCard);
    }
    modalResultCard.classList.remove('hidden');
    modalResultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function handleCalculatorSearch() {
    const searchInput = document.getElementById('calculatorSearchInput') as HTMLInputElement | null;
    if (!searchInput) return;

    const searchTerm = searchInput.value.toLowerCase().trim();
    if (!searchTerm) {
        renderCalculatorWidgetsPage(allCalculatorsData);
        return;
    }
    const trulyFiltered: CalculatorCategory[] = [];
    allCalculatorsData.forEach(category => {
        const calculatorsForThisCategory = category.calculators.filter(calc =>
            calc.name.toLowerCase().includes(searchTerm)
        );

        if (calculatorsForThisCategory.length > 0) {
            const existingCategory = trulyFiltered.find(c => c.category === category.category);
            if (existingCategory) {
                existingCategory.calculators.push(...calculatorsForThisCategory);
            } else {
                trulyFiltered.push({ ...category, calculators: calculatorsForThisCategory });
            }
        }
    });
    renderCalculatorWidgetsPage(trulyFiltered);
}


// --- Explore Tab Logic ---

function renderExploreContent() {
    // Clear previous content
    const prepHubContent = document.getElementById('prepHubContent');
    const textbooksContent = document.getElementById('textbooksContent');
    const aiimsPapersContent = document.getElementById('aiimsPapersContent');
    const compassContent = document.getElementById('compassContent');

    if(prepHubContent) prepHubContent.innerHTML = '';
    if(textbooksContent) textbooksContent.innerHTML = '';
    if(aiimsPapersContent) aiimsPapersContent.innerHTML = '';
    if(compassContent) compassContent.innerHTML = '';

    nursingWorldContent.forEach(sectionData => {
        sectionData.items.forEach(item => {
            const itemCard = document.createElement('div');
            itemCard.className = 'card-glass p-5 flex flex-col justify-between items-start text-left stagger-fade-in cursor-pointer';
            
            let cardHtml = `
                <div>
                    <h4 class="font-semibold text-lg text-text-primary leading-tight">${item.name}</h4>
                    <p class="text-sm text-text-accent mt-1">${item.brief}</p>
                </div>
            `;

            if (item.motivationalTag) {
                itemCard.classList.add('flex-col-reverse', 'justify-end'); 
                itemCard.style.backgroundImage = `linear-gradient(to right, #8b5cf6, #d946ef)`;
                cardHtml = `
                    <p class="mt-3 text-sm font-bold text-white">${item.motivationalTag}</p>
                    <div>
                        <h4 class="font-semibold text-lg text-white leading-tight">${item.name}</h4>
                        <p class="text-sm text-purple-200 mt-1">${item.brief}</p>
                    </div>
                `;
            }

            itemCard.innerHTML = cardHtml;

            if (item.type === 'exam' || item.type === 'book') {
                itemCard.addEventListener('click', () => showNursingItemDetailModal(item));
            } else if (item.type === 'podcast') {
                itemCard.addEventListener('click', () => showPodcastPlayerModal(item));
            } else { // career paths etc.
                itemCard.addEventListener('click', () => showSimpleDetailModal(item));
            }
            
            if (["nclex-rn", "aiims-norcet", "jipmer-sn", "prometric-exams"].includes(item.id)) {
                prepHubContent?.insertBefore(itemCard, prepHubContent.firstChild); // Place at top
            } else if (sectionData.section === "SNA Prep Hub: Conquer Your Exams") {
                 prepHubContent?.appendChild(itemCard); // Add to Prep Hub
            } else if (sectionData.section === "SNA Study Essentials: Resources & Insights" && item.type === 'book') {
                textbooksContent?.appendChild(itemCard);
            } else if (sectionData.section === "SNA Compass: Navigate Your Career") {
                compassContent?.appendChild(itemCard);
            }
        });
    });

    renderAiimsPapers();
    filterPodcastsByLanguage('en');
}

function renderAiimsPapers() {
    const aiimsPapersContainer = document.getElementById('aiimsPapersContent');
    if (!aiimsPapersContainer) return;
    aiimsPapersContainer.innerHTML = ''; 

    aiimsPreviousPapers.forEach(paper => {
        const paperCard = document.createElement('div');
        paperCard.className = 'card-glass p-5 flex flex-col justify-between items-start text-left stagger-fade-in cursor-pointer';
        paperCard.innerHTML = `
            <div>
                <h4 class="font-semibold text-lg text-text-primary leading-tight">AIIMS NORCET ${paper.year} ${paper.set}</h4>
                <p class="text-sm text-text-accent mt-1">Practice with real exam questions.</p>
            </div>
            <button class="mt-3 text-sm py-1.5 px-3 bg-purple-600/50 hover:bg-purple-600/70 text-white rounded-md shadow-sm">View Paper</button>
        `;
        const button = paperCard.querySelector('button');
        button?.addEventListener('click', () => viewPdfPaper(paper.file));
        aiimsPapersContainer.appendChild(paperCard);
    });
}

function viewPdfPaper(pdfFileName: string) {
    const pdfPath = `pdfs/${pdfFileName}`;
    openModal(
        `AIIMS NORCET Paper: ${pdfFileName}`,
        `<p class="text-text-secondary">This would open the PDF file in a viewer or new tab. For this demo, the file path is: code>${pdfPath}</code>.</p><p class="mt-4 text-sm text-text-accent">In a real app, you'd integrate a PDF viewer library here.</p>`,
        '',
        true
    );
}


function filterPodcastsByLanguage(lang: string) {
    const podcastListContainer = document.getElementById('podcastListContent');
    if (!podcastListContainer) return;
    
    podcastListContainer.innerHTML = '';
    document.querySelectorAll('.language-btn').forEach(btn => {
        btn.classList.remove('active');
        if ((btn as HTMLElement).dataset.lang === lang) {
            btn.classList.add('active');
        }
    });

    const podcasts = nursingWorldContent.find(s => s.section === "SNA Sound Waves: Nursing Podcasts")?.items ?? [];
    const filteredPodcasts = podcasts.filter(p => p.lang === lang);

    if (filteredPodcasts.length === 0) {
        podcastListContainer.innerHTML = `<p class="text-center text-text-accent col-span-full">No podcasts available in ${lang.toUpperCase()}.</p>`;
        return;
    }

    filteredPodcasts.forEach(podcast => {
        const podcastCard = document.createElement('div');
        podcastCard.className = 'card-glass p-5 flex flex-col justify-between items-start text-left stagger-fade-in cursor-pointer';
        podcastCard.innerHTML = `
            <div>
                <h4 class="font-semibold text-lg text-text-primary leading-tight">${podcast.name}</h4>
                <p class="text-sm text-text-accent mt-1">${podcast.brief}</p>
            </div>
            <button class="mt-3 text-sm py-1.5 px-3 bg-purple-600/50 hover:bg-purple-600/70 text-white rounded-md shadow-sm">
                <svg class="w-5 h-5 inline-block mr-1" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" /></svg>
                Play
            </button>
        `;
        const button = podcastCard.querySelector('button');
        button?.addEventListener('click', () => showPodcastPlayerModal(podcast));
        podcastListContainer.appendChild(podcastCard);
    });
}

function showPodcastPlayerModal(podcast: ExploreItem) {
    const podcastPlayerHtml = `
        <div class="text-center">
            <h3 class="text-xl font-bold text-text-primary mb-2">${podcast.name}</h3>
            <p class="text-text-accent mb-4">${podcast.brief}</p>
            <audio controls class="w-full mt-4">
                <source src="${podcast.url}" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
            <p class="text-sm text-text-secondary mt-4">Playing in ${podcast.lang?.toUpperCase()}.</p>
            <p class="text-xs text-text-accent mt-2">*(For demo: Audio URL: ${podcast.url})*</p>
        </div>
    `;
    openModal(`SNA Sound Waves: Podcast`, podcastPlayerHtml, '', true);
}


function showNursingItemDetailModal(item: ExploreItem) {
    let bodyHtml = `
        <p class="text-text-secondary mb-4">${item.brief}</p>
        ${item.motivationalTag ? `<p class="text-lg font-bold gradient-text mb-4">${item.motivationalTag}</p>` : ''}
    `;
    if (item.resources && item.resources.length > 0) {
        bodyHtml += `
            <h4 class="text-md font-semibold text-text-accent mt-5 mb-2">Key Resources:</h4>
            <ul class="list-disc list-inside text-text-secondary text-sm space-y-1">
                ${item.resources.map(res => `<li><strong>${res.type}:</strong> ${res.title} ${res.author ? `by ${res.author}` : ''}</li>`).join('')}
            </ul>
        `;
    } else {
        bodyHtml += `<p class="text-text-accent text-sm mt-4">No specific resources listed for this item.</p>`;
    }
    
    let footerHtml = '';
    if (item.type === 'exam') {
        footerHtml = `<button class="btn btn-primary w-full py-3 px-6 rounded-lg shadow-lg" data-action="goToStudyPlan" data-item-name="${sanitizeHTML(item.name)}">Go to Study Plan</button>`;
    } else if (item.type === 'book') {
        footerHtml = `<button class="btn btn-clear w-full py-3 px-6 rounded-lg" data-action="findInLibrary" data-item-name="${sanitizeHTML(item.name)}">Find in Library</button>`;
    }

    openModal(item.name, bodyHtml, footerHtml, true);
}

function showSimpleDetailModal(item: ExploreItem) {
    const bodyHtml = `
        <p class="text-text-secondary mb-4">${item.brief}</p>
        <p class="text-sm text-text-accent mt-4">More details about "${item.name}" would be presented here.</p>
    `;
    openModal(item.name, bodyHtml, '', true);
}

// --- Lab Values Tab Logic ---
function renderLabValues(filteredData: LabCategory[] = allLabValuesData) {
    const labValuesHost = document.getElementById('labValuesHost');
    const noResultsDiv = document.getElementById('no-lab-results');
    if (!labValuesHost || !noResultsDiv) return;

    labValuesHost.innerHTML = '';
    noResultsDiv.classList.toggle('hidden', filteredData.some(cat => cat.values.length > 0));

    filteredData.forEach(category => {
        if (category.values.length === 0) return;

        const categorySection = document.createElement('section');
        categorySection.className = 'mb-12';

        const categoryTitleEl = document.createElement('h2');
        categoryTitleEl.className = 'text-2xl font-bold text-text-secondary mb-6 pb-2 border-b border-b-glass-border flex items-center gap-3';
        categoryTitleEl.innerHTML = `<span class="text-3xl">${category.icon}</span> ${category.title}`;
        categorySection.appendChild(categoryTitleEl);
        
        const valuesContainer = document.createElement('div');
        valuesContainer.className = 'space-y-4';

        category.values.forEach(val => {
            const details = document.createElement('details');
            details.className = 'lab-value-card stagger-fade-in';
            
            const summary = document.createElement('summary');
            summary.innerHTML = `
                <span class="font-semibold text-text-primary">${val.test} ${val.specimen ? `<span class="text-xs font-normal text-text-accent">(${val.specimen})</span>` : ''}</span>
                <span class="summary-arrow text-text-accent">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                </span>
            `;

            const detailContent = document.createElement('div');
            detailContent.className = 'lab-value-details';
            let detailHtml = `
                <div class="lab-value-table">
                    <div class="lab-value-table-item">
                        <div class="label">Conventional Units</div>
                        <div class="value">${val.conventionalUnits || 'N/A'}</div>
                    </div>
                     <div class="lab-value-table-item">
                        <div class="label">SI Units</div>
                        <div class="value">${val.siUnits || 'N/A'}</div>
                    </div>
                </div>
                <div class="etiology-grid">
                    <div class="etiology-column">
                        <h4 class="high">Possible High Etiology</h4>
                        <div class="etiology-content">${val.etiology.high || 'N/A'}</div>
                    </div>
                     <div class="etiology-column">
                        <h4 class="low">Possible Low Etiology</h4>
                        <div class="etiology-content">${val.etiology.low || 'N/A'}</div>
                    </div>
                </div>
            `;
            
            if (val.notes) {
                detailHtml += `<div class="lab-notes"><strong>Note:</strong> ${val.notes}</div>`;
            }

            detailContent.innerHTML = detailHtml;
            
            details.appendChild(summary);
            details.appendChild(detailContent);
            valuesContainer.appendChild(details);
        });

        categorySection.appendChild(valuesContainer);
        labValuesHost.appendChild(categorySection);
    });
}


function handleLabSearch() {
    const searchInput = document.getElementById('labSearchInput') as HTMLInputElement | null;
    if (!searchInput) return;

    const searchTerm = searchInput.value.toLowerCase().trim();
    if (!searchTerm) {
        renderLabValues(allLabValuesData);
        return;
    }

    const filteredData: LabCategory[] = allLabValuesData.map(category => {
        const filteredValues = category.values.filter(value => 
            value.test.toLowerCase().includes(searchTerm)
        );
        return { ...category, values: filteredValues };
    });

    renderLabValues(filteredData);
}


// --- Tab Navigation Logic ---
function setupTabNavigation() {
    bottomNavItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetTab = (item as HTMLElement).dataset.tab;
            if (!homeContentDiv || !exploreContentDiv || !studyContentDiv || !labsContentDiv) return;
            
            bottomNavItems.forEach(navBtn => navBtn.classList.remove('active'));
            
            homeContentDiv.classList.add('hidden');
            exploreContentDiv.classList.add('hidden');
            studyContentDiv.classList.add('hidden');
            labsContentDiv.classList.add('hidden');
            
            item.classList.add('active');
            
            if (targetTab === 'home') {
                homeContentDiv.classList.remove('hidden');
                renderCalculatorWidgetsPage();
            } else if (targetTab === 'explore') {
                exploreContentDiv.classList.remove('hidden');
                renderExploreContent();
            } else if (targetTab === 'study') {
                studyContentDiv.classList.remove('hidden');
            } else if (targetTab === 'labs') {
                labsContentDiv.classList.remove('hidden');
                renderLabValues();
            }
        });
    });
}


// --- Initial Load ---
document.addEventListener('DOMContentLoaded', () => {
    renderCalculatorWidgetsPage();
    setupTabNavigation();

    modalCloseBtn?.addEventListener('click', closeModal);

    modalFooter?.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        const button = target.closest('button[data-action]');
        if (!button) return;

        const action = button.getAttribute('data-action');
        const itemName = button.getAttribute('data-item-name');

        if (action === 'goToStudyPlan') {
            alert(`Navigating to Study Tab for ${itemName} prep! (Demo)`);
            closeModal();
        } else if (action === 'findInLibrary') {
            alert(`Searching Library for ${itemName}! (Demo)`);
            closeModal();
        }
    });

    document.querySelectorAll('.language-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterPodcastsByLanguage((e.currentTarget as HTMLElement).dataset.lang ?? 'en');
        });
    });

    const viewAllAiimsPapersBtn = document.getElementById('viewAllAiimsPapersBtn');
    if (viewAllAiimsPapersBtn) {
        viewAllAiimsPapersBtn.addEventListener('click', () => {
            alert('This feature will display all available AIIMS previous year papers. (Demo)');
        });
    }

    const calculatorSearchInput = document.getElementById('calculatorSearchInput');
    calculatorSearchInput?.addEventListener('input', handleCalculatorSearch);
    
    const labSearchInput = document.getElementById('labSearchInput');
    labSearchInput?.addEventListener('input', handleLabSearch);
});